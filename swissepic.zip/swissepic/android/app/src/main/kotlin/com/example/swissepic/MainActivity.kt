package com.example.swissepic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
