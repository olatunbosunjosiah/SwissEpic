// ignore_for_file: prefer_const_constructors, camel_case_types, file_names

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:swissepic/services/firebase_auth_methods.dart';

class addexpenses extends StatefulWidget {
  const addexpenses({super.key});

  @override
  State<addexpenses> createState() => _addexpensesState();
}

class _addexpensesState extends State<addexpenses> {
DateTime selectedDate = DateTime.now();
TextEditingController odometerController = TextEditingController(); // Added text controller
TextEditingController expensesController = TextEditingController();
TextEditingController vendorController = TextEditingController();
TextEditingController totalCostController = TextEditingController();
TextEditingController notesController = TextEditingController();


@override
  void dispose() {
    odometerController.dispose();
    expensesController.dispose();
    vendorController.dispose();
    totalCostController.dispose();
    notesController.dispose();
    super.dispose();
  }
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
      

      // Call the method to store the selected date
      _storeExpensesDetails(selectedDate, context);
    }
  }
 void _storeExpensesDetails(DateTime selectedDate, BuildContext context) {

  FirebaseAuthMethods(FirebaseAuth.instance).storeExpensesDetails(
    context: context,
    selectedDate: selectedDate,
    odometerController: odometerController.text,
    expensesController: expensesController.text,
    vendorController: vendorController.text,
    totalCostController: totalCostController.text,
    notesController: notesController.text
    );
   
    
    // For this example, we'll just print the selected date
    print('Selected Date: $selectedDate');
  } 
  @override
  Widget build(BuildContext context) {
    String formattedDate = DateFormat('yyyy-MM-dd').format(selectedDate);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff2C85BC),
        leading: IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.arrow_back,
              color: Colors.white,
            )),
        centerTitle: true,
        title: Text(
          "Add Expenses",
          style: TextStyle(
            fontSize: MediaQuery.of(context).size.width / 24,
            fontFamily: "Poppins",
            color: Colors.white,
            overflow: TextOverflow.ellipsis,
            fontWeight: FontWeight.normal,
          ),
          textAlign: TextAlign.center,
        ),
        actions: [
          IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.settings,
                color: Colors.white,
              )),
          IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.save,
                color: Colors.white,
              )),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xff9D9D9D).withOpacity(0.5),
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(10.0),
                      bottomRight: Radius.circular(10.0)),
                ),
                height: MediaQuery.of(context).size.height / 20,
                width: MediaQuery.of(context).size.height / 1,
                child: Row(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width / 20,
                    ),
                    Image(
                      image: AssetImage("assets/mer.png"),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width / 10,
                    ),
                    Text(
                      "Mercedes V-class",
                      style: TextStyle(
                        fontSize: MediaQuery.of(context).size.width / 26,
                        fontFamily: "Poppins",
                        color: Colors.black,
                        overflow: TextOverflow.ellipsis,
                        fontWeight: FontWeight.normal,
                      ),
                      textAlign: TextAlign.start,
                    ),
                    Icon(
                      Icons.arrow_drop_down,
                      color: Colors.black,
                    )
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
                  
            
            SizedBox(
              height: 30,
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width / 2,
              child: Flexible(
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(5, 0, 10, 0),
                    child: Text(
              'Selected Date: $formattedDate',
              style: TextStyle(fontSize: 20),
            ),
            
                  ),
                ),
                
              ),
  IconButton(
    onPressed: () => _selectDate(context),
    tooltip: 'Select Date',
    icon: Icon(Icons.calendar_today),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width / 2,

            child: Flexible(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(5, 0, 10, 0),
                  child: TextFormField(
                    controller: odometerController,
                    cursorHeight: 18,
                    style: GoogleFonts.poppins(
                      color: Colors.black,
                      fontSize: 17,
                    ),
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      contentPadding: EdgeInsets.all(10),
                      alignLabelWithHint: true,
                      border: UnderlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(14)),
                        borderSide: BorderSide(color: Colors.grey),
                      ),
                      enabledBorder: UnderlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(14)),
                        borderSide: BorderSide(
                          color: Colors.black,
                        ),
                      ),
                      suffixText: "km",
                      labelText: "Odometer",
                      hintText: "1",
                      labelStyle: TextStyle(
                        color: Colors.grey,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),
            
            ),
            // feild

            SizedBox(
              height: MediaQuery.of(context).size.height / 30,
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Flexible(
                child: TextFormField(
                  controller: expensesController,
                  cursorHeight: 18,
                  style: GoogleFonts.poppins(
                    // backgroundColor: Color(0xff21242D),
                    color: Colors.black,
                    fontSize: 17,
                  ),
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    contentPadding: EdgeInsets.all(10),

                    // errorText: "Email ",
                    // fillColor: Color(0xff21242D),
                    alignLabelWithHint: true,
                    border: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    // labelText: "Model",
                    hintText: "Expenses",
                    suffixIcon: Icon(Icons.arrow_forward_ios_outlined),
                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ),
            //new feild vendor
            SizedBox(
              height: MediaQuery.of(context).size.height / 30,
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Flexible(
                child: TextFormField(
                  controller: vendorController,
                  cursorHeight: 18,
                  style: GoogleFonts.poppins(
                    // backgroundColor: Color(0xff21242D),
                    color: Colors.black,
                    fontSize: 17,
                  ),
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    contentPadding: EdgeInsets.all(10),

                    // errorText: "Email ",
                    // fillColor: Color(0xff21242D),
                    alignLabelWithHint: true,
                    border: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    // labelText: "Model",
                    hintText: "Vendor",
                    // suffixIcon: Icon(Icons.arrow_forward_ios_outlined),
                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ),

            // new
            SizedBox(
              height: 30,
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width / 2,
              child: Flexible(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(5, 0, 10, 0),
                  child: TextFormField(
                    controller: totalCostController,
                    cursorHeight: 18,
                    style: GoogleFonts.poppins(
                      color: Colors.black,
                      fontSize: 17,
                    ),
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      contentPadding: EdgeInsets.all(10),
                      alignLabelWithHint: true,
                      border: UnderlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(14)),
                        borderSide: BorderSide(color: Colors.grey),
                      ),
                      enabledBorder: UnderlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(14)),
                        borderSide: BorderSide(
                          color: Colors.black,
                        ),
                      ),
                      suffixText: "Eur",
                      hintText: "Total Cost",
                      labelStyle: TextStyle(
                        color: Colors.grey,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            //next

            SizedBox(
              height: MediaQuery.of(context).size.height / 30,
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Flexible(
                child: TextFormField(
                  controller: notesController,
                  cursorHeight: 18,
                  style: GoogleFonts.poppins(
                    // backgroundColor: Color(0xff21242D),
                    color: Colors.black,
                    fontSize: 17,
                  ),
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    contentPadding: EdgeInsets.all(10),

                    // errorText: "Email ",
                    // fillColor: Color(0xff21242D),
                    alignLabelWithHint: true,
                    border: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    // labelText: "Model",
                    labelText: "Notes",

                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ),
            //documents upload row

            SizedBox(
              height: MediaQuery.of(context).size.height / 30,
            ),
            Row(
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 10),
                  child: InkWell(
                    splashColor: Colors.black,
                    hoverColor: Colors.black,
                    onTap: () {},
                    child: Image(
                      image: AssetImage(
                        "assets/upload.png",
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width / 20,
                ),
                Text(
                  "Attach Receipt",
                  style: TextStyle(
                    fontSize: MediaQuery.of(context).size.width / 24,
                    fontFamily: "Poppins",
                    color: Colors.black,
                    overflow: TextOverflow.ellipsis,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.start,
                ),
              ],
            ),
            ElevatedButton(
  onPressed: (){
     _storeExpensesDetails(selectedDate, context);
     Navigator.pop(context); 
  },
  child: Text('Save'),
),
            SizedBox(
              height: MediaQuery.of(context).size.height / 10,
            ),
          ],
        ),
      ),
    );
  }
}
