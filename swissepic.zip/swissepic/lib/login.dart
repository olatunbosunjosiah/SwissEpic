// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, camel_case_types

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:swissepic/register.dart';
import 'package:swissepic/services/firebase_auth_methods.dart';
import 'package:swissepic/widgets/logincheckbox.dart';

import 'bottomnav.dart';

class login extends StatefulWidget {
  const login({super.key});

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> loginUser() async {
    final navigator = Navigator.of(context);
    final loginresult =
        await FirebaseAuthMethods(FirebaseAuth.instance).loginWithEmail(
      email: emailController.text.trim(),
      password: passwordController.text.trim(),
      context: context,
    );
    if (loginresult) {
      //navigating to success screen
      final user = FirebaseAuth.instance.currentUser;
      navigator.push(
        MaterialPageRoute(
          builder: (context) => MyBottomNavigationBar(
            userId: user?.uid ?? '',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        // scrollDirection: Axis.vertical,
        child: Column(
          children: [
            Stack(
              children: [
                // Background Image
                Image.asset(
                  "assets/page1.png", // Replace with your image path
                  fit: BoxFit.cover,
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                ),
                //  BottomSheet
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: MediaQuery.of(context).size.height / 2.1,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                        )),
                    padding: EdgeInsets.only(
                      top: 40,
                      left: 20,
                      right: 20,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          children: [
                            Container(
                              height: 56,
                              decoration: BoxDecoration(
                                color: Colors
                                    .white, // Background color of the container
                                borderRadius: BorderRadius.circular(
                                    15), // Optional: Add border radius
                                boxShadow: [
                                  BoxShadow(
                                    color: Color.fromARGB(255, 238, 240, 245)
                                        .withOpacity(0.5), // Shadow color
                                    spreadRadius: 5, // Spread radius
                                    blurRadius: 7, // Blur radius
                                    offset: Offset(0,
                                        3), // Offset to control the shadow's position
                                  ),
                                ],
                              ),
                              child: TextFormField(
                                style: TextStyle(color: Colors.black),
                                cursorHeight: 18,
                                keyboardType: TextInputType.emailAddress,
                                controller: emailController,
                                decoration: const InputDecoration(
                                    contentPadding: EdgeInsets.all(20.0),
                                    fillColor: Color(0xff303236),
                                    // errorText: "Email ",
                                    // fillColor: Color(0xff21242D),
                                    alignLabelWithHint: true,
                                    border: InputBorder.none,
                                    prefixIcon: Icon(
                                      Icons.person_2_outlined,
                                      color: Colors.grey,
                                    ),
                                    hintText: "Email",
                                    hintStyle: TextStyle(
                                      color: Colors.grey,
                                      fontSize: 14,
                                      fontFamily: 'Poppins',
                                    ),
                                    isCollapsed: true),
                                //   onChanged: (val) {
                                //     validateEmail(val);
                                //   },
                                // ),
                                // Text(
                                //   _errorMessage,
                                //   style: const TextStyle(color: Colors.red),
                                // ),
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Column(
                          children: [
                            Container(
                              height: 56,
                              decoration: BoxDecoration(
                                color: Colors
                                    .white, // Background color of the container
                                borderRadius: BorderRadius.circular(
                                    15), // Optional: Add border radius
                                boxShadow: [
                                  BoxShadow(
                                    color: Color.fromARGB(255, 238, 240, 245)
                                        .withOpacity(0.5), // Shadow color
                                    spreadRadius: 5, // Spread radius
                                    blurRadius: 7, // Blur radius
                                    offset: Offset(0,
                                        3), // Offset to control the shadow's position
                                  ),
                                ],
                              ),
                              child: TextFormField(
                                style: TextStyle(color: Colors.black),
                                cursorHeight: 18,
                                keyboardType: TextInputType.emailAddress,
                                controller: passwordController,
                                decoration: const InputDecoration(
                                    contentPadding: EdgeInsets.all(20.0),
                                    fillColor: Color(0xff303236),
                                    // errorText: "Email ",
                                    // fillColor: Color(0xff21242D),
                                    alignLabelWithHint: true,
                                    border: InputBorder.none,
                                    prefixIcon: Icon(
                                      Icons.lock_outline,
                                      color: Colors.grey,
                                    ),
                                    suffixIcon:
                                        Icon(Icons.visibility_off_outlined),
                                    hintText: "*******",
                                    hintStyle: TextStyle(
                                      color: Colors.grey,
                                      fontSize: 14,
                                      fontFamily: 'Poppins',
                                    ),
                                    isCollapsed: true),
                                //   onChanged: (val) {
                                //     validateEmail(val);
                                //   },
                                // ),
                                // Text(
                                //   _errorMessage,
                                //   style: const TextStyle(color: Colors.red),
                              ),
                            ),
                          ],
                        ),
                        logincheckbox(),
                        SizedBox(
                          height: MediaQuery.of(context).size.height / 60,
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: MediaQuery.of(context).size.width / 21,
                              right: MediaQuery.of(context).size.width / 21),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              minimumSize: const Size.fromHeight(60),
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(10), // <-- Radius
                              ),
                              backgroundColor: Color(0xff2C85BC), // NEW
                              elevation: 10,
                            ),
                            onPressed: () {
                              loginUser();
                            },
                            child: Text(
                              "LOGIN",
                              softWrap: true,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                decoration: TextDecoration.none,
                                color: Color(0xffffffff),
                                fontWeight: FontWeight.w700,
                                fontSize:
                                    MediaQuery.of(context).size.width / 20,
                                fontFamily: 'Open Sans',
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).size.height / 100,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Don’t have an account?",
                              style: TextStyle(
                                fontSize:
                                    MediaQuery.of(context).size.width / 26,
                                fontFamily: 'Poppins',
                                color: Colors.black,
                                overflow: TextOverflow.ellipsis,
                                fontWeight: FontWeight.w400,
                              ),
                              textAlign: TextAlign.start,
                            ),
                            TextButton(
                              child: Text(
                                "Register",
                                style: TextStyle(
                                  fontSize:
                                      MediaQuery.of(context).size.width / 26,
                                  fontFamily: 'Poppins',
                                  color: Color(0xffD1111A),
                                  overflow: TextOverflow.ellipsis,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => register()));
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      resizeToAvoidBottomInset:
          true, // Set this to false to prevent excess space
    );
  }
}
