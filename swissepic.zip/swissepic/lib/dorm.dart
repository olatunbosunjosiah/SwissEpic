// ignore_for_file: camel_case_types, prefer_const_constructors, prefer_const_literals_to_create_immutables
import 'package:flutter/material.dart';
import 'package:swissepic/add%20expenses.dart';
import 'package:swissepic/fillup.dart';

import 'markdamage2.dart';
import 'vehicle details.dart';
import 'widgets/imageslidr.dart';

class homescreendorm extends StatefulWidget {
  const homescreendorm({super.key});

  @override
  State<homescreendorm> createState() => _homescreendormState();
}

class _homescreendormState extends State<homescreendorm> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff8FD1FF),
        centerTitle: true,
        leading: Builder(
          builder: (BuildContext context) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap: () {
                  Scaffold.of(context).openDrawer();
                },
                child: Image(
                  image: AssetImage("assets/swisslogo.png"),
                  width: MediaQuery.of(context).size.width / 2,
                ),
              ),
            );
          },
        ),
        title: Image(
          image: AssetImage("assets/homemain.png"),
          width: MediaQuery.of(context).size.width / 3,
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image(
              image: AssetImage("assets/search.png"),
              width: MediaQuery.of(context).size.width / 16,
            ),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF162033), Color(0xFF2C85BC)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                children: [
                  Icon(
                    Icons.menu,
                    color: Colors.white,
                  ),
                ],
              ),
            ),
            Center(
              child: Column(
                children: [
                  Text("MERCEDES-BENZ GLE",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: MediaQuery.of(context).size.width / 20)),
                  Text("(ZH 639 638)",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                          fontSize: MediaQuery.of(context).size.width / 20)),
                  //space
                  SizedBox(
                    height: MediaQuery.of(context).size.height / 80,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      //row1
                      Padding(
                        padding: EdgeInsets.only(
                          left: MediaQuery.of(context).size.width / 80,
                          right: MediaQuery.of(context).size.width / 80,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: InkWell(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => fillup()));
                                },
                                child: Column(
                                  children: [
                                    Image(
                                      image: AssetImage("assets/car.png"),
                                      width: MediaQuery.of(context).size.width /
                                          15,
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Add Refill",
                                      style: TextStyle(
                                          fontSize: MediaQuery.of(context)
                                                  .size
                                                  .width /
                                              30,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: InkWell(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              vehicledetails()));
                                },
                                child: Column(
                                  children: [
                                    Image(
                                      image: AssetImage("assets/service.png"),
                                      width: MediaQuery.of(context).size.width /
                                          15,
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Add Service",
                                      style: TextStyle(
                                          fontSize: MediaQuery.of(context)
                                                  .size
                                                  .width /
                                              30,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: InkWell(
                                onTap: () {},
                                child: Column(
                                  children: [
                                    Image(
                                      image: AssetImage("assets/remarks.png"),
                                      width: MediaQuery.of(context).size.width /
                                          15,
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Add Remarks",
                                      style: TextStyle(
                                          fontSize: MediaQuery.of(context)
                                                  .size
                                                  .width /
                                              30,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      //space
                      SizedBox(
                        height: MediaQuery.of(context).size.height / 40,
                      ),
                      //row2
                      Padding(
                        padding: EdgeInsets.only(
                          right: MediaQuery.of(context).size.width / 40,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Column(
                                children: [
                                  Image(
                                    image: AssetImage("assets/startingkm.png"),
                                    width:
                                        MediaQuery.of(context).size.width / 20,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    "Starting km",
                                    style: TextStyle(
                                        fontSize:
                                            MediaQuery.of(context).size.width /
                                                30,
                                        color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Column(
                                children: [
                                  Image(
                                    image: AssetImage("assets/endingkm.png"),
                                    width:
                                        MediaQuery.of(context).size.width / 20,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    "Ending km",
                                    style: TextStyle(
                                        fontSize:
                                            MediaQuery.of(context).size.width /
                                                30,
                                        color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: InkWell(
                                onTap: (){
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => markdamage2()));
                                },
                                child: Column(
                                children: [
                                  Image(
                                    image: AssetImage("assets/carclean.png"),
                                    width:
                                        MediaQuery.of(context).size.width / 15,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    "Car Clean",
                                    style: TextStyle(
                                        fontSize:
                                            MediaQuery.of(context).size.width /
                                                30,
                                        color: Colors.white),
                                  ),
                                ],
                              ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height / 40,
                      ),
                      Center(
                        child: Padding(
                          padding: EdgeInsets.all(10.0),
                          child: InkWell(
                            onTap: () {
                               Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => addexpenses()));
                            },
                            child: Column(
                              children: [
                                Image(
                                  image: AssetImage("assets/parkingcost.png"),
                                  width: MediaQuery.of(context).size.width / 40,
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "Parking Cost",
                                  style: TextStyle(
                                      fontSize:
                                          MediaQuery.of(context).size.width /
                                              30,
                                      color: Colors.white),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      MySlider(),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
