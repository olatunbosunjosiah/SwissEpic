// ignore_for_file: prefer_const_constructors, camel_case_types, annotate_overrides

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:swissepic/bottomnav.dart';
import 'package:swissepic/login.dart';

class splash extends StatefulWidget {
  const splash({super.key});

  @override
  State<splash> createState() => _splashState();
}

class _splashState extends State<splash> {
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 5), () => loginCheck());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
            child: SizedBox(
      height: MediaQuery.of(context).size.height / 1,
      width: MediaQuery.of(context).size.width / 1,
      child: Image(
        image: AssetImage("assets/splash.png"),
        fit: BoxFit.cover,
      ),
    )));
  }

  void loginCheck() {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => MyBottomNavigationBar(
                  userId: user.uid,
                )),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => login()),
      );
    }
  }
}
