import 'package:flutter/material.dart';

class NotificationPage extends StatelessWidget {
  final List<Map<String, String>> notifications; // Pass your notifications here

  const NotificationPage({super.key, required this.notifications});

 @override
  Widget build(BuildContext context) {
    if (notifications.isEmpty) {
      // No notifications, show a container or a message
             return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff8FD1FF),
        centerTitle: true,
        leading: Builder(
          builder: (BuildContext context) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap: () {
                  Scaffold.of(context).openDrawer();
                },
                child: Image(
                  image: AssetImage("assets/swisslogo.png"),
                  width: MediaQuery.of(context).size.width / 2,
                ),
              ),
            );
          },
        ),
        title: Image(
          image: AssetImage("assets/notificationconainer.png"),
          width: MediaQuery.of(context).size.width / 3,
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image(
              image: AssetImage("assets/search.png"),
              width: MediaQuery.of(context).size.width / 16,
            ),
          ),
        ],
      ),
      body: const Center(
          child: Text('No notifications found.'),
        ),
      );
     
     
  } else {
      // Notifications available, display them
      
      return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff8FD1FF),
        centerTitle: true,
        leading: Builder(
          builder: (BuildContext context) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap: () {
                  Scaffold.of(context).openDrawer();
                },
                child: Image(
                  image: AssetImage("assets/swisslogo.png"),
                  width: MediaQuery.of(context).size.width / 2,
                ),
              ),
            );
          },
        ),
        title: Image(
          image: AssetImage("assets/notificationconainer.png"),
          width: MediaQuery.of(context).size.width / 3,
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image(
              image: AssetImage("assets/search.png"),
              width: MediaQuery.of(context).size.width / 16,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 15),
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xff56A5D8),
                    borderRadius: BorderRadius.all(Radius.circular(16)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Padding(
                              padding: EdgeInsets.all(18.0),
                              child: Image(
                                image: AssetImage("assets/download.png"),
                                width: MediaQuery.of(context).size.width / 15,
                              ),
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Upload Successful",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    fontSize: MediaQuery.of(context).size.width/25,
                                  ),
                                ),
                                Text(
                                  "Image 238.jpg was uploaded successfully",
                                  style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    color: Colors.white,
                                    fontSize: MediaQuery.of(context).size.width/40,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              "34m ago",
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                                color: Colors.white,
                                fontSize: MediaQuery.of(context).size.width/30,
                              ),
                            ),
                            Image(
                              image: AssetImage("assets/img11.png"),
                              width: MediaQuery.of(context).size.width / 10,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 15),
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xff56A5D8),
                    borderRadius: BorderRadius.all(Radius.circular(16)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Padding(
                              padding: EdgeInsets.all(18.0),
                              child: Image(
                                image: AssetImage("assets/download.png"),
                                width: MediaQuery.of(context).size.width / 15,
                              ),
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Upload Successful",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    fontSize: MediaQuery.of(context).size.width/25,
                                  ),
                                ),
                                Text(
                                  "Image 238.jpg was uploaded successfully",
                                  style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    color: Colors.white,
                                    fontSize: MediaQuery.of(context).size.width/40,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              "34m ago",
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                                color: Colors.white,
                                fontSize: MediaQuery.of(context).size.width/30,
                              ),
                            ),
                            Image(
                              image: AssetImage("assets/img11.png"),
                              width: MediaQuery.of(context).size.width / 10,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  
     

  
    }
  //   return Scaffold(
  //     appBar: AppBar(
  //       backgroundColor: Color(0xff8FD1FF),
  //       centerTitle: true,
  //       leading: Builder(
  //         builder: (BuildContext context) {
  //           return Padding(
  //             padding: const EdgeInsets.all(8.0),
  //             child: GestureDetector(
  //               onTap: () {
  //                 Scaffold.of(context).openDrawer();
  //               },
  //               child: Image(
  //                 image: AssetImage("assets/swisslogo.png"),
  //                 width: MediaQuery.of(context).size.width / 2,
  //               ),
  //             ),
  //           );
  //         },
  //       ),
  //       title: Image(
  //         image: AssetImage("assets/notificationconainer.png"),
  //         width: MediaQuery.of(context).size.width / 3,
  //       ),
  //       actions: [
  //         Padding(
  //           padding: const EdgeInsets.all(8.0),
  //           child: Image(
  //             image: AssetImage("assets/search.png"),
  //             width: MediaQuery.of(context).size.width / 16,
  //           ),
  //         ),
  //       ],
  //     ),
  //     body: SingleChildScrollView(
  //       child: Padding(
  //         padding: const EdgeInsets.all(8.0),
  //         child: Column(
  //           children: [
  //             Padding(
  //               padding: const EdgeInsets.only(top: 15),
  //               child: Container(
  //                 decoration: BoxDecoration(
  //                   color: Color(0xff56A5D8),
  //                   borderRadius: BorderRadius.all(Radius.circular(16)),
  //                 ),
  //                 child: Padding(
  //                   padding: const EdgeInsets.all(15),
  //                   child: Row(
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                     children: [
  //                       Row(
  //                         children: [
  //                           Padding(
  //                             padding: EdgeInsets.all(18.0),
  //                             child: Image(
  //                               image: AssetImage("assets/download.png"),
  //                               width: MediaQuery.of(context).size.width / 15,
  //                             ),
  //                           ),
  //                           Column(
  //                             mainAxisAlignment: MainAxisAlignment.start,
  //                             crossAxisAlignment: CrossAxisAlignment.start,
  //                             children: [
  //                               Text(
  //                                 "Upload Successful",
  //                                 style: TextStyle(
  //                                   fontWeight: FontWeight.bold,
  //                                   color: Colors.white,
  //                                   fontSize: MediaQuery.of(context).size.width/25,
  //                                 ),
  //                               ),
  //                               Text(
  //                                 "Image 238.jpg was uploaded successfully",
  //                                 style: TextStyle(
  //                                   fontWeight: FontWeight.normal,
  //                                   color: Colors.white,
  //                                   fontSize: MediaQuery.of(context).size.width/40,
  //                                 ),
  //                               ),
  //                             ],
  //                           ),
  //                         ],
  //                       ),
  //                       Column(
  //                         mainAxisAlignment: MainAxisAlignment.end,
  //                         crossAxisAlignment: CrossAxisAlignment.end,
  //                         children: [
  //                           Text(
  //                             "34m ago",
  //                             style: TextStyle(
  //                               fontWeight: FontWeight.normal,
  //                               color: Colors.white,
  //                               fontSize: MediaQuery.of(context).size.width/30,
  //                             ),
  //                           ),
  //                           Image(
  //                             image: AssetImage("assets/img11.png"),
  //                             width: MediaQuery.of(context).size.width / 10,
  //                           ),
  //                         ],
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //             ),
  //             Padding(
  //               padding: const EdgeInsets.only(top: 15),
  //               child: Container(
  //                 decoration: BoxDecoration(
  //                   color: Color(0xff56A5D8),
  //                   borderRadius: BorderRadius.all(Radius.circular(16)),
  //                 ),
  //                 child: Padding(
  //                   padding: const EdgeInsets.all(15),
  //                   child: Row(
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                     children: [
  //                       Row(
  //                         children: [
  //                           Padding(
  //                             padding: EdgeInsets.all(18.0),
  //                             child: Image(
  //                               image: AssetImage("assets/download.png"),
  //                               width: MediaQuery.of(context).size.width / 15,
  //                             ),
  //                           ),
  //                           Column(
  //                             mainAxisAlignment: MainAxisAlignment.start,
  //                             crossAxisAlignment: CrossAxisAlignment.start,
  //                             children: [
  //                               Text(
  //                                 "Upload Successful",
  //                                 style: TextStyle(
  //                                   fontWeight: FontWeight.bold,
  //                                   color: Colors.white,
  //                                   fontSize: MediaQuery.of(context).size.width/25,
  //                                 ),
  //                               ),
  //                               Text(
  //                                 "Image 238.jpg was uploaded successfully",
  //                                 style: TextStyle(
  //                                   fontWeight: FontWeight.normal,
  //                                   color: Colors.white,
  //                                   fontSize: MediaQuery.of(context).size.width/40,
  //                                 ),
  //                               ),
  //                             ],
  //                           ),
  //                         ],
  //                       ),
  //                       Column(
  //                         mainAxisAlignment: MainAxisAlignment.end,
  //                         crossAxisAlignment: CrossAxisAlignment.end,
  //                         children: [
  //                           Text(
  //                             "34m ago",
  //                             style: TextStyle(
  //                               fontWeight: FontWeight.normal,
  //                               color: Colors.white,
  //                               fontSize: MediaQuery.of(context).size.width/30,
  //                             ),
  //                           ),
  //                           Image(
  //                             image: AssetImage("assets/img11.png"),
  //                             width: MediaQuery.of(context).size.width / 10,
  //                           ),
  //                         ],
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //             ),
  //           ],
  //         ),
  //       ),
  //     ),
  //   );
  // }
  // @override
  // Widget build(BuildContext context) {
    // if (notifications.isEmpty) {
    //   // No notifications, show a container or a message
    //   return Scaffold(
    //     appBar: AppBar(
    //       title: const Text('Notifications'),
    //     ),
      //   body: const Center(
      //     child: Text('No notifications found.'),
      //   ),
      // );
    // } else {
  //     // Notifications available, display them
  //     return Scaffold(
  //       appBar: AppBar(
  //         title: const Text('Notifications'),
  //       ),
  //       body: ListView.builder(
  //         itemCount: notifications.length,
  //         itemBuilder: (context, index) {
  //           final notification = notifications[index];
  //           return ListTile(
  //             leading: Image.network(notification['imageUrl'] ?? ''),
  //             title: Text('Car ID: ${notification['carId']}'),
  //             subtitle: Text('Plate Number: ${notification['plateNo']}'),
  //           );
  //         },
  //       ),
  //     );
  //   }
  // }

}
}