import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../widgets/showSnackbar.dart';

class FirebaseAuthMethods {
  late final FirebaseAuth _auth;

  FirebaseAuthMethods(FirebaseAuth instance) {
    _auth = FirebaseAuth.instance;
  }
//email sign up
  Future<User?> signUpWithEmail(
      {required email,
      required password,
      required usrname,
      required BuildContext context}) async {
    try {
      final result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      log("result:$result");
      log("result:${result.user?.uid}");
      await sendEmailVerification(context);

      User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        String userId = user.uid;
        await FirebaseFirestore.instance.collection('users').doc(userId).set({
          'username': usrname,
          'email': email,
          'id': userId,
          // Other user data you may want to store
        });

        //.then((_) {
        //       print('User information added to the "users" collection');
        //       // Once user information is added, you can add the subcollection.
        //       var selectedValue;
        //       var selectedValue2;
        //       var selectedValue3;
        //       var selectedValue4;
        //       var selectedValue5;
        //       var selectedValue6;
        //       var selectedValue7;
        //       var selectedPlateNo;
        //       var drivernameController;
        //       storeInfo(selectedValue: selectedValue,
        //       selectedValue2: selectedValue2,
        //       selectedValue3: selectedValue3,
        //       selectedValue4: selectedValue4,
        //       selectedValue5: selectedValue5,
        //       selectedValue6: selectedValue6,
        //       selectedValue7: selectedValue7,
        //       selectedPlateNo: selectedPlateNo,
        //       drivernameController: drivernameController,
        //       context: context);
        //     });
        print('User ID: $userId');
      } else {
        print('No user is currently signed in.');
      }
    } on FirebaseAuthException catch (e) {
      showSnackBar(context, e.message!);
    }
    return null;
  }

  //Email Login
  Future<bool> loginWithEmail(
      {required String email,
      required String password,
      required BuildContext context}) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      if (!_auth.currentUser!.emailVerified) {
        await sendEmailVerification(context);
        return false;
      } else {
        return true;
      }
    } on FirebaseAuthException catch (e) {
      showSnackBar(context, e.message!);
      return false;
    }
  }

  // Email Verification
  Future<void> sendEmailVerification(BuildContext context) async {
    try {
      _auth.currentUser!.sendEmailVerification();
      showSnackBar(context, 'Email Verification Has Been Sent');
    } on FirebaseAuthException catch (e) {
      showSnackBar(context, e.message!);
    }
  }

  Future<void> storeInfo(
      {String? drivernameController,
      String? uniqueId,
      required selectedValue,
      required selectedPlateNo,
      required selectedValue2,
      required selectedValue3,
      required selectedValue4,
      required selectedValue5,
      required selectedValue6,
      required selectedValue7,
      required BuildContext context}) async {
    try {
// Get the currently signed-in user
      User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        String userId = user.uid;

        // Reference to the Firestore collection for users
        CollectionReference usersCollection =
            FirebaseFirestore.instance.collection('users');

        // Create a reference to the user's document using their UID
        DocumentReference userDocRef = usersCollection.doc(userId);

        // Create a subcollection called "posts" within the user's document
        CollectionReference postsSubcollection =
            userDocRef.collection('checkindetails');

        // Now, you can add documents (posts) to the "posts" subcollection
        // For example:
        postsSubcollection.add({
          'Check-in': selectedValue,
          'PlateNo': selectedPlateNo,
          'Is there any damage to the vehicle?': selectedValue2,
          'The tire profile meets the requirements?': selectedValue3,
          'Is the vehicle clean inside?': selectedValue4,
          'Is the vehicle clean on the outside?': selectedValue5,
          'Is there any damage to  vehicle?': selectedValue6,
          'Is the vehicle tank full?': selectedValue7,
          "driver's name": drivernameController,
        });
      } else {
        print('No user is currently signed in.');
      }

//     //   final CollectionReference radioValues =
//     //     FirebaseFirestore.instance.collection('radioValues');
//     // await radioValues.add({
//     //   'option': selectedValue,
//     // });

//     //   await FirebaseFirestore.instance.collection('users').doc(uid).set({
//     // 'username': usrname,
//     // // Other user data you may want to store

//   //});
//   await FirebaseFirestore.instance
//       .collection('users')
//       .doc(uid)
//       .collection('parkingHistory')
//       .doc(uniqueId)
//       .set

// // // Reference to the 'users' collection
// // CollectionReference usersCollection = FirebaseFirestore.instance.collection('users');

// // // Reference to the document within 'users' collection using 'uid'
// // DocumentReference userDocument = usersCollection.doc(uid);

// // // Reference to the sub-collection 'checkindetails' inside the document
// // CollectionReference checkinDetailsCollection = userDocument.collection('checkindetails');

// // await checkinDetailsCollection.update

// ({
// 'Check-in': selectedValue,
//  'PlateNo':selectedPlateNo,
//  'Is there any damage to the vehicle?':selectedValue2,
//  'The tire profile meets the requirements?':selectedValue3,
//  'Is the vehicle clean inside?':selectedValue4,
//  'Is the vehicle clean on the outside?':selectedValue5,
//  'Is there any damage to  vehicle?':selectedValue6,
//  'Is the vehicle tank full?':selectedValue7,
//       });

// //   await FirebaseFirestore.instance
// //       .collection('users')
// //       .doc(uid)
// //       .collection('checkindetails')
// //       .doc(uniqueId)
// //       .set({
// //  'Check-in': selectedValue,
// //  'PlateNo':selectedPlateNo,
// //  'Is there any damage to the vehicle?':selectedValue2,
// //  'The tire profile meets the requirements?':selectedValue3,
// //  'Is the vehicle clean inside?':selectedValue4,
// //  'Is the vehicle clean on the outside?':selectedValue5,
// //  'Is there any damage to  vehicle?':selectedValue6,
// //  'Is the vehicle tank full?':selectedValue7,
// //       });
    } on FirebaseAuthException catch (e) {
      showSnackBar(context, e.message!);
    }
    return;
  }

  Future<void> storeVehicleDetails(
      {String? uniqueId,
      String? makeController,
      String? modelController,
      String? licenceNoController,
      String? vinController,
      String? insuranceController,
      String? remarksController,
      String? selectedValue8,
      required BuildContext context}) async {
    try {
// Get the currently signed-in user
      User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        String userId = user.uid;

        // Reference to the Firestore collection for users
        CollectionReference usersCollection =
            FirebaseFirestore.instance.collection('users');

        // Create a reference to the user's document using their UID
        DocumentReference userDocRef = usersCollection.doc(userId);

        // Create a subcollection called "posts" within the user's document
        CollectionReference postsSubcollection =
            userDocRef.collection('vehicledetails');

        // Now, you can add documents (posts) to the "posts" subcollection
        // For example:
        postsSubcollection.add({
          'make': makeController,
          'model': modelController,
          'year': "",
          'licenceno': licenceNoController,
          'vin': vinController,
          'insurance': insuranceController,
          'Is the vehicle tank full?': selectedValue8,
          'remarks': remarksController,
        });
      } else {
        print('No user is currently signed in.');
      }

//     //   final CollectionReference radioValues =
//     //     FirebaseFirestore.instance.collection('radioValues');
//     // await radioValues.add({
//     //   'option': selectedValue,
//     // });

//     //   await FirebaseFirestore.instance.collection('users').doc(uid).set({
//     // 'username': usrname,
//     // // Other user data you may want to store

//   //});
//   await FirebaseFirestore.instance
//       .collection('users')
//       .doc(uid)
//       .collection('parkingHistory')
//       .doc(uniqueId)
//       .set

// // // Reference to the 'users' collection
// // CollectionReference usersCollection = FirebaseFirestore.instance.collection('users');

// // // Reference to the document within 'users' collection using 'uid'
// // DocumentReference userDocument = usersCollection.doc(uid);

// // // Reference to the sub-collection 'checkindetails' inside the document
// // CollectionReference checkinDetailsCollection = userDocument.collection('checkindetails');

// // await checkinDetailsCollection.update

// ({
// 'Check-in': selectedValue,
//  'PlateNo':selectedPlateNo,
//  'Is there any damage to the vehicle?':selectedValue2,
//  'The tire profile meets the requirements?':selectedValue3,
//  'Is the vehicle clean inside?':selectedValue4,
//  'Is the vehicle clean on the outside?':selectedValue5,
//  'Is there any damage to  vehicle?':selectedValue6,
//  'Is the vehicle tank full?':selectedValue7,
//       });

// //   await FirebaseFirestore.instance
// //       .collection('users')
// //       .doc(uid)
// //       .collection('checkindetails')
// //       .doc(uniqueId)
// //       .set({
// //  'Check-in': selectedValue,
// //  'PlateNo':selectedPlateNo,
// //  'Is there any damage to the vehicle?':selectedValue2,
// //  'The tire profile meets the requirements?':selectedValue3,
// //  'Is the vehicle clean inside?':selectedValue4,
// //  'Is the vehicle clean on the outside?':selectedValue5,
// //  'Is there any damage to  vehicle?':selectedValue6,
// //  'Is the vehicle tank full?':selectedValue7,
// //       });
    } on FirebaseAuthException catch (e) {
      showSnackBar(context, e.message!);
    }
    return;
  }

  Future<void> storeFillUpDetails(
      {DateTime? selectedDate,
      String? viagemController,
      String? quantityController,
      String? priceController,
      String? totalCostController,
      String? fillingStationController,
      String? notesController,
      required String selectedDateController,
      required BuildContext context}) async {
    try {
// Get the currently signed-in user
      User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        String userId = user.uid;

        // Reference to the Firestore collection for users
        CollectionReference usersCollection =
            FirebaseFirestore.instance.collection('users');

        // Create a reference to the user's document using their UID
        DocumentReference userDocRef = usersCollection.doc(userId);

        // Create a subcollection called "posts" within the user's document
        CollectionReference postsSubcollection =
            userDocRef.collection('fillupdetails');

        // Now, you can add documents (posts) to the "posts" subcollection
        // For example:
        postsSubcollection.add({
          'selected date': selectedDateController,
          'viagem': '${viagemController}Km',
          'quantity': '$quantityController Ltr',
          'price': '$priceController Eur',
          'total cost': '$totalCostController',
          'filling station': '$fillingStationController',
          'notes': '$notesController',
          'attach receipt': ''
//     'model': modelController,
//  'year':"",
//  'licenceno':licenceNoController,
//  'vin':vinController,
//  'insurance':insuranceController,
//  'Is the vehicle tank full?':selectedValue8,
//  'remarks':remarksController,
        });
      } else {
        print('No user is currently signed in.');
      }
    } on FirebaseAuthException catch (e) {
      showSnackBar(context, e.message!);
    }
    return;
  }

  Future<void> storeExpensesDetails(
      {DateTime? selectedDate,
      String? odometerController,
      String? expensesController,
      String? vendorController,
      String? totalCostController,
      String? notesController,
      required BuildContext context}) async {
    try {
// Get the currently signed-in user
      User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        String userId = user.uid;

        // Reference to the Firestore collection for users
        CollectionReference usersCollection =
            FirebaseFirestore.instance.collection('users');

        // Create a reference to the user's document using their UID
        DocumentReference userDocRef = usersCollection.doc(userId);

        // Create a subcollection called "posts" within the user's document
        CollectionReference postsSubcollection =
            userDocRef.collection('expensesdetails');

        // Now, you can add documents (posts) to the "posts" subcollection
        // For example:
        postsSubcollection.add({
          'selected date': selectedDate,
          'odometer': '${odometerController}Km',
          'expenses': '$expensesController Ltr',
          'vendor': '$vendorController',
          'total cost': '$totalCostController',
          'notes': '$notesController',
          'attach receipt': ''
//     'model': modelController,
//  'year':"",
//  'licenceno':licenceNoController,
//  'vin':vinController,
//  'insurance':insuranceController,
//  'Is the vehicle tank full?':selectedValue8,
//  'remarks':remarksController,
        });
      } else {
        print('No user is currently signed in.');
      }
    } on FirebaseAuthException catch (e) {
      showSnackBar(context, e.message!);
    }
    return;
  }

  // Future<User?> signInWithEmailAndPassword(String email, String password) async{

  //   try{
  //     UserCredential credential = await _auth.signInWithEmailAndPassword(email: email, password: password);
  //     return credential.user;
  //   } catch (e) {
  //     print("error (very wrong)");
  //   }
  //   return null;
  // }
}

class FormCompletionProvider with ChangeNotifier {
  bool _driverChecklistFormCompleted = false;
  bool _fillupFormCompleted = false;
  bool _vehicleDetailsFormCompleted = false;

  // Add getters and setters for each form completion status

  bool get driverChecklistFormCompleted => _driverChecklistFormCompleted;
  bool get fillupFormCompleted => _fillupFormCompleted;
  bool get vehicleDetailsFormCompleted => _vehicleDetailsFormCompleted;

  // Implement methods to update the form completion status

  void updateDriverChecklistFormStatus(bool completed) {
    _driverChecklistFormCompleted = completed;
    notifyListeners();
  }

  void updateFillupFormStatus(bool completed) {
    _fillupFormCompleted = completed;
    notifyListeners();
  }

  void updateVehicleDetailsFormStatus(bool completed) {
    _vehicleDetailsFormCompleted = completed;
    notifyListeners();
  }
}
