
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:swissepic/services/firebase_auth_methods.dart';

import 'widgets/checkbox.dart';

class fillup extends StatefulWidget {
  const fillup({super.key});

  @override
  State<fillup> createState() => _fillupState();
}

class _fillupState extends State<fillup> {
  
  @override
  Widget build(BuildContext context) {

    
return Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xff2C85BC),
          leading: IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              )),
          centerTitle: true,
          title: Text(
            "Add Fill-Up",
            style: TextStyle(
              fontSize: MediaQuery.of(context).size.width / 24,
              fontFamily: "Poppins",
              color: Colors.white,
              overflow: TextOverflow.ellipsis,
              fontWeight: FontWeight.normal,
            ),
            textAlign: TextAlign.center,
          ),
          actions: [
            IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.settings,
                  color: Colors.white,
                )),
            IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.save,
                  color: Colors.white,
                )),
          ],
        ),
        body: FillForm(),
        );}
}

class FillForm extends StatefulWidget {
  const FillForm({super.key});

  @override
  State<FillForm> createState() => _FillFormState();
}

class _FillFormState extends State<FillForm> {
DateTime? selectedDate; 
 // Initialize as null
TextEditingController viagemController = TextEditingController(); 
 // Added text controller
TextEditingController quantityController = TextEditingController();

TextEditingController priceController = TextEditingController();

TextEditingController totalCostController = TextEditingController();

TextEditingController fillingStationController = TextEditingController();

TextEditingController notesController = TextEditingController();
  TextEditingController selectedDateController = TextEditingController(); // Define the controller here

 String? dropdownValue;
 String? viagemDropdownValue;
String? priceDropdownValue;
String? totalCostDropdownValue;
// Define similar variables for other fields


@override
  void dispose() {
    viagemController.dispose();
    quantityController.dispose();
    priceController.dispose();
    totalCostController.dispose();
    fillingStationController.dispose();
    notesController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        selectedDateController.text = "${picked.toLocal()}".split(' ')[0];
      });
    }
  }


 void _storeFillUpDetails(DateTime selectedDate, BuildContext context) {

  FirebaseAuthMethods(FirebaseAuth.instance).storeFillUpDetails(
    context: context,
    selectedDate: selectedDate,
    viagemController: viagemController.text,
    quantityController: quantityController.text,
    priceController: priceController.text,
    totalCostController: totalCostController.text,
    fillingStationController: fillingStationController.text,
    notesController: notesController.text,
    selectedDateController:selectedDateController.text
    );
   
    
    // For this example, we'll just print the selected date
    print('Selected Date: $selectedDate');
  } 

  @override
  Widget build(BuildContext context) {
     String formattedDate = selectedDate != null
        ? DateFormat('yyyy-MM-dd').format(selectedDate!)
        : '';
    return SingleChildScrollView(
  child: Column(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Center(
        child: Container(
          decoration: BoxDecoration(
            color: Color(0xff9D9D9D).withOpacity(0.5),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(10.0),
              bottomRight: Radius.circular(10.0),
            ),
          ),
          height: MediaQuery.of(context).size.height / 20,
          width: MediaQuery.of(context).size.height / 1,
          child: Row(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width / 20,
              ),
              Image(
                image: AssetImage("assets/mer.png"),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width / 10,
              ),
              Text(
                "Mercedes V-class",
                style: TextStyle(
                  fontSize: MediaQuery.of(context).size.width / 26,
                  fontFamily: "Poppins",
                  color: Colors.black,
                  overflow: TextOverflow.ellipsis,
                  fontWeight: FontWeight.normal,
                ),
                textAlign: TextAlign.start,
              ),
              Icon(
                Icons.arrow_drop_down,
                color: Colors.black,
              )
            ],
          ),
        ),
      ),
      SizedBox(height: 10),
          Row(
            children: [
              Flexible(
                child: // Selected Date (TextFormField)
Padding(
  padding: EdgeInsets.all(10),
  child: TextFormField(
    readOnly: true, // To make it non-editable
    controller: selectedDateController,
    decoration: InputDecoration(
      labelText: 'Selected Date',
      hintText: 'Select a date',
      suffixIcon: IconButton(
        onPressed: () {
          _selectDate(context); // Open the date picker when the icon is clicked
        },
        icon: Icon(Icons.calendar_today),
      ),
    ),
    onTap: () {
      _selectDate(context); // Also open the date picker when the text field is tapped
    },
  ),
),
              ),
              // IconButton(
              //   onPressed: () => _selectDate(context),
              //   tooltip: 'Select Date',
              //   icon: Icon(Icons.calendar_today),
              // ),
            ],
          ),
          // Rest of your form elements...

          // Viagem (Example Text Form Field)
         // Viagem (Example Text Form Field with Dropdown)
Padding(
  padding: EdgeInsets.all(10),
  child: Row(
    children: [
      Flexible(
        flex: 3,
        child: TextFormField(
          controller: viagemController,
          decoration: InputDecoration(
            labelText: 'Viagem',
            hintText: 'Enter Viagem',
          ),
        ),
      ),
      Flexible(
        flex: 2,
        child: DropdownButton<String>(
          value: viagemDropdownValue, // Set the initial value here
          onChanged: (String? newValue) {
            setState(() {
              viagemDropdownValue = newValue;
            });
          },
          items: <String>['Option 1', 'Option 2', 'Option 3', 'Option 4'] // Dropdown items
              .map<DropdownMenuItem<String>>((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
        ),
      ),
    ],
  ),
),


          // Quantity (Example Text Form Field)
          // TextFormField for "Quantity" with DropdownButton
Padding(
  padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
  child: Row(
    children: [
      Flexible(
        child: TextFormField(
          cursorHeight: 18,
          controller: quantityController,
          style: GoogleFonts.poppins(
            color: Colors.black,
            fontSize: 17,
          ),
          decoration: InputDecoration(
            // Your input decoration for Quantity
            labelText: 'Quantity',
                hintText: 'Enter Quantity',
          ),
        ),
      ),
      DropdownButton<String>(
        value: dropdownValue, // You can set the initial value here
        icon: Icon(Icons.arrow_drop_down), // Dropdown icon
        onChanged: (String? newValue) {
          // Handle dropdown item selection here
          setState(() {
            dropdownValue = newValue;
          });
        },
        items: <String>['Kg', 'Ltr', 'Gallons', 'Others'] // Dropdown items
            .map<DropdownMenuItem<String>>((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    ],
  ),
),

// Similarly, add DropdownButton widgets for other form fields

          // Price (Example Text Form Field)
          Padding(
            padding: EdgeInsets.all(5),
            child: TextFormField(
              controller: priceController,
              decoration: InputDecoration(
                labelText: 'Price',
                hintText: 'Enter Price',
              ),
            ),
          ),

          // Total Cost (Example Text Form Field)
          Padding(
            padding: EdgeInsets.all(10),
            child: TextFormField(
              controller: totalCostController,
              decoration: InputDecoration(
                labelText: 'Total Cost',
                hintText: 'Enter Total Cost',
              ),
            ),
          ),

          // Filling Station (Example Text Form Field)
          Padding(
            padding: EdgeInsets.all(10),
            child: TextFormField(
              controller: fillingStationController,
              decoration: InputDecoration(
                labelText: 'Filling Station',
                hintText: 'Enter Filling Station',
              ),
            ),
          ),

          // Notes (Example Text Form Field)
          Padding(
            padding: EdgeInsets.all(5),
            child: TextFormField(
              controller: notesController,
              decoration: InputDecoration(
                labelText: 'Notes',
                hintText: 'Enter Notes',
              ),
            ),
          ),

          // Attach Receipt Button (Example)
          Row(
            children: [
              Padding(
                padding: EdgeInsets.only(left: 10),
                child: InkWell(
                  splashColor: Colors.black,
                  hoverColor: Colors.black,
                  onTap: () {
                    // Implement your logic for attaching receipts
                  },
                  child: Image(
                    image: AssetImage("assets/upload.png"),
                  ),
                ),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width / 30,
              ),
              Text(
                "Attach Receipt",
                style: TextStyle(
                  fontSize: MediaQuery.of(context).size.width / 24,
                  fontFamily: "Poppins",
                  color: Colors.black,
                  overflow: TextOverflow.ellipsis,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.start,
              ),
            ],
          ),

          // Save Button (Example)
          ElevatedButton(
            onPressed: () {
              _storeFillUpDetails(selectedDate!, context);
              Navigator.pop(context);
            },
            child: Text('Save'),
          ),

          // Row
          // Rest of your form elements...
         

      // Rest of your form elements...
      // ... (The rest of your form elements)
    ],
  ),
);

    
//     Column(
//         mainAxisAlignment: MainAxisAlignment.start,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Center(
//             child: Container(
//               decoration: BoxDecoration(
//                 color: Color(0xff9D9D9D).withOpacity(0.5),
//                 borderRadius: BorderRadius.only(
//                   bottomLeft: Radius.circular(10.0),
//                   bottomRight: Radius.circular(10.0),
//                 ),
//               ),
//               height: MediaQuery.of(context).size.height / 20,
//               width: MediaQuery.of(context).size.height / 1,
//               child: Row(
//                 children: [
//                   SizedBox(
//                     width: MediaQuery.of(context).size.width / 20,
//                   ),
//                   Image(
//                     image: AssetImage("assets/mer.png"),
//                   ),
//                   SizedBox(
//                     width: MediaQuery.of(context).size.width / 10,
//                   ),
//                   Text(
//                     "Mercedes V-class",
//                     style: TextStyle(
//                       fontSize: MediaQuery.of(context).size.width / 26,
//                       fontFamily: "Poppins",
//                       color: Colors.black,
//                       overflow: TextOverflow.ellipsis,
//                       fontWeight: FontWeight.normal,
//                     ),
//                     textAlign: TextAlign.start,
//                   ),
//                   Icon(
//                     Icons.arrow_drop_down,
//                     color: Colors.black,
//                   )
//                 ],
//               ),
//             ),
//           ),
//           SizedBox(height: 10),
//           Row(
//             children: [
//               Flexible(
//                 child: Padding(
//                   padding: EdgeInsets.fromLTRB(5, 0, 10, 0),
//                   child: Text(
//                     'Selected Date: ${selectedDate ?? "Select a date"}',
//                     style: TextStyle(fontSize: 20, decoration: TextDecoration.underline),
//                   ),
//                 ),
//               ),
//               IconButton(
//                 onPressed: () => _selectDate(context),
//                 tooltip: 'Select Date',
//                 icon: Icon(Icons.calendar_today),
//               ),
//             ],
//           ),
//           // Rest of your form elements...

//           // Viagem (Example Text Form Field)
//           Padding(
//             padding: EdgeInsets.all(5),
//             child: TextFormField(
//               controller: viagemController,
//               decoration: InputDecoration(
//                 labelText: 'Viagem',
//                 hintText: 'Enter Viagem',
//               ),
//             ),
//           ),

//           // Quantity (Example Text Form Field)
//           // TextFormField for "Quantity" with DropdownButton
// Padding(
//   padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
//   child: Row(
//     children: [
//       Flexible(
//         child: TextFormField(
//           cursorHeight: 18,
//           controller: quantityController,
//           style: GoogleFonts.poppins(
//             color: Colors.black,
//             fontSize: 17,
//           ),
//           decoration: InputDecoration(
//             // Your input decoration for Quantity
//             labelText: 'Quantity',
//                 hintText: 'Enter Quantity',
//           ),
//         ),
//       ),
//       DropdownButton<String>(
//         value: dropdownValue, // You can set the initial value here
//         icon: Icon(Icons.arrow_drop_down), // Dropdown icon
//         onChanged: (String? newValue) {
//           // Handle dropdown item selection here
//           setState(() {
//             dropdownValue = newValue;
//           });
//         },
//         items: <String>['Kg', 'Ltr', 'Gallons', 'Others'] // Dropdown items
//             .map<DropdownMenuItem<String>>((String value) {
//           return DropdownMenuItem<String>(
//             value: value,
//             child: Text(value),
//           );
//         }).toList(),
//       ),
//     ],
//   ),
// ),

// // Similarly, add DropdownButton widgets for other form fields

//           // Price (Example Text Form Field)
//           Padding(
//             padding: EdgeInsets.all(5),
//             child: TextFormField(
//               controller: priceController,
//               decoration: InputDecoration(
//                 labelText: 'Price',
//                 hintText: 'Enter Price',
//               ),
//             ),
//           ),

//           // Total Cost (Example Text Form Field)
//           Padding(
//             padding: EdgeInsets.all(10),
//             child: TextFormField(
//               controller: totalCostController,
//               decoration: InputDecoration(
//                 labelText: 'Total Cost',
//                 hintText: 'Enter Total Cost',
//               ),
//             ),
//           ),

//           // Filling Station (Example Text Form Field)
//           Padding(
//             padding: EdgeInsets.all(10),
//             child: TextFormField(
//               controller: fillingStationController,
//               decoration: InputDecoration(
//                 labelText: 'Filling Station',
//                 hintText: 'Enter Filling Station',
//               ),
//             ),
//           ),

//           // Notes (Example Text Form Field)
//           Padding(
//             padding: EdgeInsets.all(5),
//             child: TextFormField(
//               controller: notesController,
//               decoration: InputDecoration(
//                 labelText: 'Notes',
//                 hintText: 'Enter Notes',
//               ),
//             ),
//           ),

//           // Attach Receipt Button (Example)
//           Row(
//             children: [
//               Padding(
//                 padding: EdgeInsets.only(left: 10),
//                 child: InkWell(
//                   splashColor: Colors.black,
//                   hoverColor: Colors.black,
//                   onTap: () {
//                     // Implement your logic for attaching receipts
//                   },
//                   child: Image(
//                     image: AssetImage("assets/upload.png"),
//                   ),
//                 ),
//               ),
//               SizedBox(
//                 width: MediaQuery.of(context).size.width / 30,
//               ),
//               Text(
//                 "Attach Receipt",
//                 style: TextStyle(
//                   fontSize: MediaQuery.of(context).size.width / 24,
//                   fontFamily: "Poppins",
//                   color: Colors.black,
//                   overflow: TextOverflow.ellipsis,
//                   fontWeight: FontWeight.bold,
//                 ),
//                 textAlign: TextAlign.start,
//               ),
//             ],
//           ),

//           // Save Button (Example)
//           ElevatedButton(
//             onPressed: () {
//               _storeFillUpDetails(selectedDate!, context);
//               Navigator.pop(context);
//             },
//             child: Text('Save'),
//           ),

//           // Row
//           // Rest of your form elements...
//           ElevatedButton(
//             onPressed: () {
//               _storeFillUpDetails(selectedDate!, context );
//               Navigator.pop(context);
//             },
//             child: Text('Save'),
//           ),
        
//         ],
//       );
 
  }
}















