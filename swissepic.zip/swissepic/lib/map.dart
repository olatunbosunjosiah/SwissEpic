// ignore_for_file: prefer_const_constructors, camel_case_types

import 'package:flutter/material.dart';

class map extends StatefulWidget {
  const map({super.key});

  @override
  State<map> createState() => _mapState();
}

class _mapState extends State<map> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Expanded(
          child: Image(
            image: AssetImage("assets/map.png"),
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}
