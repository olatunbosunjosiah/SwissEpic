// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, camel_case_types

import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:swissepic/models/car.dart';

import 'report.dart';

class home extends StatefulWidget {
  const home({
    super.key,
    required this.userId,
  });

  final String userId;

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  final List<Map<String, String?>> dataList = [
    {
      'text': 'Item 1',
      'image': 'assets/3.png',
    },
    {
      'text': 'Item 2',
      'image': 'assets/3.png',
    },
    {
      'text': 'Item 3',
      'image': 'assets/3.png',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 80, 157, 212),
          centerTitle: true,
          leading: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image(
              image: AssetImage("assets/swisslogo.png"),
              width: MediaQuery.of(context).size.width / 2,
            ),
          ),
          title: Image(
            image: AssetImage("assets/homemain.png"),
            width: MediaQuery.of(context).size.width / 3,
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Image(
                image: AssetImage("assets/search.png"),
                width: MediaQuery.of(context).size.width / 16,
              ),
            ),
          ],
        ),
        body: CarList(
          userId: widget.userId,
        ));
  }
}

class CarList extends StatelessWidget {
  CarList({
    super.key,
    required this.userId,
  });
  final String userId;

  Future<List<Car>> fetchCarsFromFirestore() async {
    try {
      QuerySnapshot<Map<String, dynamic>> carSnapshot =
          await FirebaseFirestore.instance.collection('cars').get();
      List<Car> carList = [];

      for (var element in carSnapshot.docs) {
        carList.add(Car.fromJson(element.data()));
      }
      return carList;
    } catch (e) {
      return [];
    }
  }

  final List<String> imagePaths = [
    'assets/1.png',
    'assets/2.png',
    'assets/3.png',
    'assets/1.png',
    'assets/2.png',
    'assets/3.png',
    'assets/1.png',
    'assets/2.png',
    'assets/3.png',
    'assets/1.png',
    'assets/2.png',
    'assets/3.png',
    'assets/1.png',
    'assets/2.png',
    'assets/3.png',
    // Add more image paths for each ListTile
  ];
  final List<String> bagValues = [
    '3 Bags', // Value for the first container
    '5 Bags', // Value for the second container
    '2 Bags', // Value for the third container
    '3 Bags', // Value for the first container
    '5 Bags', // Value for the second container
    '2 Bags', // Value for the third container
    '3 Bags', // Value for the first container
    '5 Bags', // Value for the second container
    '2 Bags', // Value for the third container
    '3 Bags', // Value for the first container
    '5 Bags', // Value for the second container
    '2 Bags', // Value for the third container
    '3 Bags', // Value for the first container
    '5 Bags', // Value for the second container
    '2 Bags', // Value for the third container
    // Add more values for each ListTile
  ];
  final List<String> passengersValues = [
    '5 Passengers', // Value for the first container
    '8 Passengers', // Value for the second container
    '6 Passengers', // Value for the third container
    '5 Passengers', // Value for the first container
    '8 Passengers', // Value for the second container
    '6 Passengers', // Value for the third container
    '5 Passengers', // Value for the first container
    '8 Passengers', // Value for the second container
    '6 Passengers', // Value for the third container
    '5 Passengers', // Value for the first container
    '8 Passengers', // Value for the second container
    '6 Passengers', // Value for the third container
    '5 Passengers', // Value for the first container
    '8 Passengers', // Value for the second container
    '6 Passengers', // Value for the third container
    // Add more values for each ListTile
  ];

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: fetchCarsFromFirestore(),
      builder: (context, AsyncSnapshot<List<Car>> snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        if (!snapshot.hasData && snapshot.data!.isEmpty) {
          return Center(child: Text('No cars found'));
        }
        final List<Car> carList = snapshot.data!;
final status = carData['status'] ?? false;
        return ListView.builder(
          itemCount: carList.length,
          itemBuilder: (context, index) {
            final carData = carList[index];

            return ListTile(
                title: Container(
              height: MediaQuery.of(context).size.height / 3.8,
              width: MediaQuery.of(context).size.width / 4.04,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [const Color(0xFF60A3CD), const Color(0xFF3189BF)],
                  begin: const FractionalOffset(0.0, 0.0),
                  end: const FractionalOffset(1.0, 0.0),
                  stops: [0.0, 1.0],
                  tileMode: TileMode.clamp,
                ),
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
              child: Row(
                children: [
                  Padding(
                    padding: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width / 80,
                      // right: MediaQuery.of(context).size.width / 40,
                    ),
                    child: carData.imageUrl != null
                        ? Image.network(
                            carData
                                .imageUrl!, // Use the URL from the 'image' field
                            width: MediaQuery.of(context).size.width /
                                3, // Adjust the image width
                            height: MediaQuery.of(context).size.height /
                                3.8, // Match the container height
                            fit: BoxFit.contain,
                          )
                        : Image.network(
                            'https://imgtr.ee/images/2023/10/17/46fd535d934f655ab60a72f1904e865f.jpeg', // Replace with the actual URL of your image
                            width: MediaQuery.of(context).size.width /
                                3, // Adjust the image width
                            height: MediaQuery.of(context).size.height /
                                3.8, // Match the container height
                            fit: BoxFit.contain,
                          ), // A placeholder or alternative widget to show when imageUrl is null

                    // child: Image.asset(
                    //   imagePaths[index],
                    //   width: MediaQuery.of(context).size.width / 3, // Adjust the image width
                    //   height: MediaQuery.of(context).size.height / 3.8, // Match the container height
                    // ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height / 30,
                      ),
                      Text(
                        carData.name ?? '',
                        style: TextStyle(
                          fontSize: MediaQuery.of(context).size.width / 21,
                          fontFamily: "Poppins",
                          color: Colors.white,
                          overflow: TextOverflow.ellipsis,
                          fontWeight: FontWeight.w700,
                        ),
                        textAlign: TextAlign.start,
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height / 200,
                      ),
                      Text(
                        carData.plateNo ??
                            '', // Replace 'description' with your field name,
                        style: TextStyle(
                          fontSize: MediaQuery.of(context).size.width / 26,
                          fontFamily: "Poppins",
                          color: Colors.white,
                          overflow: TextOverflow.ellipsis,
                          fontWeight: FontWeight.normal,
                        ),
                        textAlign: TextAlign.start,
                      ),
                      Row(
                        children: [
                          Container(
                            height: MediaQuery.of(context).size.height / 30,
                            width: MediaQuery.of(context).size.width /
                                4, // Adjust the width
                            decoration: BoxDecoration(
                              color: Color(0xffE3F3FF),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(50)),
                            ),
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(Icons.luggage),
                                  Text(
                                    bagValues[index],
                                    style: TextStyle(
                                      fontSize:
                                          MediaQuery.of(context).size.width /
                                              30,
                                      fontFamily: "Poppins",
                                      color: Color(0xff2C85BC),
                                      overflow: TextOverflow.ellipsis,
                                      fontWeight: FontWeight.normal,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width / 100,
                          ),
                          Container(
                            height: MediaQuery.of(context).size.height / 30,
                            width: MediaQuery.of(context).size.width /
                                4, // Adjust the width
                            decoration: BoxDecoration(
                              color: Color(0xffE3F3FF),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(50)),
                            ),
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(Icons.people),
                                  SizedBox(width: 4.0),
                                  Text(
                                    passengersValues[index],
                                    style: TextStyle(
                                      fontSize:
                                          MediaQuery.of(context).size.width /
                                              45,
                                      fontFamily: "Poppins",
                                      color: Color(0xff2C85BC),
                                      overflow: TextOverflow.ellipsis,
                                      fontWeight: FontWeight.normal,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height / 30,
                      ),
                      //CHECKING BUTTON
                      Row(
                        children: [
                          InkWell(
                            hoverColor: Colors.white,
                            splashColor: Colors.white,
                            onTap: () {
                              log("currentPickedUserId:${carData.currentPickedUserId}");
                              log("currentUserId:$userId");
                              //checkout
                              if (carData.currentPickedUserId == userId) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => CheckInPage(
                                      carId: carData.name ?? '',
                                      plateNo: carData.plateNo ?? '',
                                      imagePath: carData.imageUrl ??
                                          '', // Provide a default empty string if 'image' is null
                                    ),
                                  ),
                                );
                              } else {
                                //check In
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => CheckInPage(
                                      carId: carData.name ?? '',
                                      plateNo: carData.plateNo ?? '',
                                      imagePath: carData.imageUrl ??
                                          '', // Provide a default empty string if 'image' is null
                                    ),
                                  ),
                                );
                              }

                              // Handle Check-in action
                              // This button is enabled if status is true
                            },
                            // Disable the button if status is false

                            child: Container(
                              height: MediaQuery.of(context).size.height / 20,
                              width: MediaQuery.of(context).size.width / 4.5,
                              decoration: BoxDecoration(
                                color: Color(0xff60A3CD),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(50)),
                              ),
                              child: Center(
                                child: Text(
                                  carData.currentPickedUserId == userId
                                      ? "Check out"
                                      : "Check in",
                                  style: TextStyle(
                                    fontSize:
                                        MediaQuery.of(context).size.width / 28,
                                    fontFamily: "Poppins",
                                    color: Colors.white,
                                    overflow: TextOverflow.ellipsis,
                                    fontWeight: FontWeight.normal,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width / 100,
                          ),
                          //CHECKOUT BUTTON
                          // InkWell(
                          //   hoverColor: Colors.white,
                          //   splashColor: Colors.white,
                          //   onTap: carData.status!
                          //       ? () {
                          //           Navigator.push(
                          //             context,
                          //             MaterialPageRoute(
                          //               builder: (context) => CheckInPage(
                          //                 carId: carData.name ?? '',
                          //                 plateNo: carData.plateNo ?? '',
                          //                 imagePath: carData.imageUrl ??
                          //                     '', // Provide a default empty string if 'image' is null
                          //               ),
                          //             ),
                          //           );

                          //           // Handle Check-in action
                          //           // This button is enabled if status is true
                          //         }
                          //       : null,
                          //   child: Container(
                          //     height:
                          //         MediaQuery.of(context).size.height / 20,
                          //     width:
                          //         MediaQuery.of(context).size.width / 4.5,
                          //     decoration: BoxDecoration(
                          //       color: Color(0xff60A3CD),
                          //       borderRadius:
                          //           BorderRadius.all(Radius.circular(50)),
                          //     ),
                          //     child: Center(
                          //       child: Text(
                          //         "Check out",
                          //         style: TextStyle(
                          //           fontSize: MediaQuery.of(context)
                          //                   .size
                          //                   .width /
                          //               34,
                          //           fontFamily: "Poppins",
                          //           color: Colors.white,
                          //           overflow: TextOverflow.ellipsis,
                          //           fontWeight: FontWeight.normal,
                          //         ),
                          //         textAlign: TextAlign.center,
                          //       ),
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ));
          },
        );
      },
    );
  }
}



// ListView.builder(
      //   itemCount: dataList.length,
      //   itemBuilder: (context, index) {
      //     final item = dataList[index];
      //     return ListTile(
      //       leading: Image.asset(item['image']!),
      //       title: Text(item['text']!),
      //       subtitle: Column(
      //         crossAxisAlignment: CrossAxisAlignment.start,
      //         children: [
      //           Text('Additional Info 1'),
      //           Text('Additional Info 2'),
      //         ],
      //       ),
      //       trailing: ElevatedButton(
      //         onPressed: () {
      //           // Button action here
      //         },
      //         child: Text('Button'),
      //       ),
      //     );
      //   },
      // ),
    