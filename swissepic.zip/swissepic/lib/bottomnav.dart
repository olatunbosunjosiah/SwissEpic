// ignore_for_file: unused_import, library_private_types_in_public_api, use_key_in_widget_constructors, prefer_final_fields, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:swissepic/dorm.dart';
import 'package:swissepic/home.dart';
import 'package:swissepic/report.dart';
import 'package:swissepic/report_page/report_page.dart';

import 'notification.dart';
import 'settings.dart';

class MyBottomNavigationBar extends StatefulWidget {
  const MyBottomNavigationBar({
    super.key,
    required this.userId,
  });
  final String userId;

  @override
  _MyBottomNavigationBarState createState() => _MyBottomNavigationBarState();
}

class _MyBottomNavigationBarState extends State<MyBottomNavigationBar> {
  int _selectedIndex = 0;

  List<Widget> _pages = [];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  void initState() {
    _pages = [
      home(userId: widget.userId),
      homescreendorm(),
      NotificationPage(notifications: const []),
      settingsscreen(),
    ];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Image.asset(
              'assets/home.png',
              width: 40, // Set width here
              height: 40, // Set height here
            ),
            label: '',
            backgroundColor: Color(0xff348BC1),
          ),
          BottomNavigationBarItem(
            icon: Image.asset(
              'assets/caricon.png',
              width: 40, // Set width here
              height: 40, // Set height here
            ),
            label: '',
            backgroundColor: Color(0xff348BC1),
          ),
          BottomNavigationBarItem(
            icon: Image.asset(
              'assets/bell.png',
              width: 40, // Set width here
              height: 40, // Set height here
            ),
            label: '',
            backgroundColor: Color(0xff348BC1),
          ),
          BottomNavigationBarItem(
            icon: Image.asset(
              'assets/settings.png',
              width: 40, // Set width here
              height: 40, // Set height here
            ),
            label: '',
            backgroundColor: Color(0xff348BC1),
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey, // Set unselected item color
        onTap: _onItemTapped,
      ),
    );
  }
}
