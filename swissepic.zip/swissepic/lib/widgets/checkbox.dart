// ignore_for_file: camel_case_types, prefer_const_constructors, unnecessary_this

import 'package:flutter/material.dart';

class checkox1 extends StatefulWidget {
  const checkox1({super.key});

  @override
  State<checkox1> createState() => _checkox1State();
}

class _checkox1State extends State<checkox1> {
  bool? valuefirst = false;
  bool? valuesecond = false;
  bool? valuethird = false;
  bool? valuefourth = false;
  bool? valuefifth = false;
  bool? valuesixth = false;
  bool? valueseventh = false;
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Checkbox(
          checkColor: Colors.white,
          activeColor: Color(0xff2C85BC),
          value: this.valuefirst,
          onChanged: (newBool) {
            setState(() {
              this.valuefirst = newBool;
            });
          },
        ),
        Text(
          "Partial Tank ",
          style: TextStyle(
            fontSize: MediaQuery.of(context).size.width / 24,
            fontFamily: "SF Pro Display",
            color: Colors.grey,
            overflow: TextOverflow.ellipsis,
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.start,
        ),
      ],
    );
  }
}
