// ignore_for_file: file_names, prefer_const_constructors

import 'package:flutter/material.dart';

class MyWidget extends StatefulWidget {
  const MyWidget({super.key});

  @override
  State<MyWidget> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MyWidget> {
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      TextFormField(
        style: TextStyle(color: Colors.white),
        cursorHeight: 18,
        keyboardType: TextInputType.emailAddress,
        decoration: const InputDecoration(
            contentPadding: EdgeInsets.all(20.0),
            fillColor: Color(0xff303236),
            // errorText: "Email ",
            // fillColor: Color(0xff21242D),
            alignLabelWithHint: true,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(10),
              ),
              borderSide: BorderSide(color: Colors.grey),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(14)),
              borderSide: BorderSide(
                color: Color(0xff7B7B7B),
              ),
            ),
            prefixIcon: Icon(
              Icons.person,
              color: Colors.grey,
            ),
            hintText: "First Name",
            hintStyle: TextStyle(
              color: Colors.white,
              fontSize: 14,
            ),
            isCollapsed: true),
      ),
      const SizedBox(height: 10),
    ]);
  }
}
