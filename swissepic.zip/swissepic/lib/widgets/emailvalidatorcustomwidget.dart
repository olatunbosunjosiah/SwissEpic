// ignore_for_file: prefer_const_constructors, library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'package:email_validator/email_validator.dart';

class Emailfield extends StatefulWidget {
  const Emailfield({super.key});

  @override
  _EmailfieldState createState() => _EmailfieldState();
}

class _EmailfieldState extends State<Emailfield> {
  String _errorMessage = '';
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextFormField(
          style: TextStyle(color: Colors.grey),
          cursorHeight: 18,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(
              contentPadding: EdgeInsets.all(20.0),
              fillColor: Color(0xff303236),
              // errorText: "Email ",
              // fillColor: Color(0xff21242D),
              alignLabelWithHint: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(10),
                ),
                borderSide: BorderSide(color: Colors.grey),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(14)),
                borderSide: BorderSide(
                  color: Color(0xff7B7B7B),
                ),
              ),
              prefixIcon: Icon(
                Icons.person_2_outlined,
                color: Colors.grey,
              ),
              hintText: "Email",
              hintStyle: TextStyle(
                color: Colors.grey,
                fontSize: 14,
              ),
              isCollapsed: true),
          onChanged: (val) {
            validateEmail(val);
          },
        ),
        Text(
          _errorMessage,
          style: const TextStyle(color: Colors.red),
        ),
      ],
    );
  }

  void validateEmail(String val) {
    if (val.isEmpty) {
      setState(() {
        _errorMessage = "Email can not be empty";
      });
    } else if (!EmailValidator.validate(val, true)) {
      setState(() {
        _errorMessage = "Invalid Email Address";
      });
    } else {
      setState(() {
        _errorMessage = "";
      });
    }
  }
}
