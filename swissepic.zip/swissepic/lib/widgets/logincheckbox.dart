// ignore_for_file: camel_case_types, prefer_const_constructors, unnecessary_this

import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';

class logincheckbox extends StatefulWidget {
  const logincheckbox({super.key});

  @override
  State<logincheckbox> createState() => _logincheckboxState();
}

class _logincheckboxState extends State<logincheckbox> {
  bool light = true;
  bool? valuefirst = false;
  bool? valuesecond = false;
  bool? valuethird = false;
  bool? valuefourth = false;
  bool? valuefifth = false;
  bool? valuesixth = false;
  bool? valueseventh = false;
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          
          children: [
            FlutterSwitch(
              width: 40.0,
              height: 22.0,
              toggleSize: 20.0,
            value: light,
            activeColor: Colors.redAccent,
            inactiveColor: Colors.grey,
             // Shadow color
            onToggle:(bool value) {
                // This is called when the user toggles the switch.
              setState(() {
                  light = value;
                });
            },
            ),
            // Switch(
              
            //   activeTrackColor: Color(0xffD1111A),
            //   // This bool value toggles the switch.
              
            //   activeColor: Colors.white,
            //   onChanged: (bool value) {
            //     // This is called when the user toggles the switch.
                
            //   },
            // ),

            // Checkbox(
            //   checkColor: Colors.white,
            //   activeColor: Color(0xffD1111A),
            //   value: this.valuefirst,
            //   onChanged: (newBool) {
            //     setState(() {
            //       this.valuefirst = newBool;
            //     });
            //   },
            // ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                "Remember me",
                style: TextStyle(
                  fontSize: MediaQuery.of(context).size.width / 26,
                  fontFamily: 'Poppins',
                  color: Colors.grey,
                  overflow: TextOverflow.ellipsis,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.start,
              ),
            ),
          ],
        ),
        Row(
          children: [
            TextButton(
              child: Text(
                "Forgot Password?",
                style: TextStyle(
                   fontSize: MediaQuery.of(context).size.width / 26,
                  fontFamily: 'Poppins',
                  color: Colors.grey,
                  overflow: TextOverflow.ellipsis,
                  fontWeight: FontWeight.w500
                ),
              ),
              onPressed: () {},
            ),
          ],
        )
      ],
    );
  }
}
