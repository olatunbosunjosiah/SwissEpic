// ignore_for_file: use_key_in_widget_constructors, library_private_types_in_public_api, prefer_const_constructors

import 'package:flutter/material.dart';

class MySlider extends StatefulWidget {
  @override
  _MySliderState createState() => _MySliderState();
}

class _MySliderState extends State<MySlider> {
  final List<String> imageUrls = [
    'assets/carimg1.png',
    'assets/carimg2.png',
    'assets/carimg3.png',
    'assets/carimg4.png',
    'assets/carimg5.png',
    // Add more image paths here
  ];

  final int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
                  padding: EdgeInsets.all(10.0), // Add padding here
                  width: MediaQuery.of(context).size.width,
                  child: Image.asset(
                    "assets/carimg1.png",
                    fit: BoxFit.cover,
                  ),
                );
  }
}
