// ignore_for_file: prefer_const_constructors, prefer_const_constructors_in_immutables, prefer_typing_uninitialized_variables, depend_on_referenced_packages

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class SignupProfileImage extends StatefulWidget {
  SignupProfileImage({Key? key}) : super(key: key);

  @override
  State<SignupProfileImage> createState() => _SignupProfileImageState();
}

class _SignupProfileImageState extends State<SignupProfileImage> {
  bool isUploadImage = false;
  var selectedImage;

  uploadProfileImage() async {
    var picker = ImagePicker();
    var image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        selectedImage = image.path;
      });
    }
    if (!mounted) return;
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 140,
      right: 0,
      left: 0,
      child: SizedBox(
        width: MediaQuery.of(context).size.width / 40,
        child: Stack(
          clipBehavior: Clip.none,
          fit: StackFit.expand,
          children: [
            CircleAvatar(
              backgroundImage: isUploadImage && selectedImage != null
                  ? FileImage(File(selectedImage))
                  : AssetImage('assets/picker.png') as ImageProvider,
            ),
            Positioned(
              bottom: -20,
              left: -50,
              right: -50,
              child: SizedBox(
                height: MediaQuery.of(context).size.height / 18,
                width: MediaQuery.of(context).size.width / 18,
                child: RawMaterialButton(
                  onPressed: () {
                    uploadProfileImage();
                    setState(() {
                      isUploadImage = true;
                    });
                  },
                  elevation: 2.0,
                  fillColor: Colors.white,
                  padding: const EdgeInsets.all(5.0),
                  shape: const CircleBorder(),
                  child: const Icon(
                    Icons.camera_alt_outlined,
                    color: Colors.blue,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
