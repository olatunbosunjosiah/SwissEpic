// ignore_for_file: prefer_const_constructors, camel_case_types

import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';

class passwordfeild extends StatefulWidget {
  const passwordfeild({super.key});

  @override
  State<passwordfeild> createState() => _passwordfeildState();
}

class _passwordfeildState extends State<passwordfeild> {
  String _errorMessage = '';
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextFormField(
          style: TextStyle(color: Colors.white),
          cursorHeight: 18,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(
              contentPadding: EdgeInsets.all(20.0),
              fillColor: Color(0xff303236),
              // errorText: "Email ",
              // fillColor: Color(0xff21242D),
              alignLabelWithHint: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(10),
                ),
                borderSide: BorderSide(color: Colors.grey),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(14)),
                borderSide: BorderSide(
                  color: Color(0xff7B7B7B),
                ),
              ),
              prefixIcon: Icon(
                Icons.lock_outline,
                color: Colors.grey,
              ),
              suffixIcon: Icon(Icons.visibility_off_outlined),
              hintText: "*******",
              hintStyle: TextStyle(
                color: Colors.grey,
                fontSize: 14,
              ),
              isCollapsed: true),
          onChanged: (val) {
            validateEmail(val);
          },
        ),
        Text(
          _errorMessage,
          style: const TextStyle(color: Colors.red),
        ),
      ],
    );
  }

  void validateEmail(String val) {
    if (val.isEmpty) {
      setState(() {
        _errorMessage = "Enter your password";
      });
    } else if (!EmailValidator.validate(val, true)) {
      setState(() {
        _errorMessage = "Invalid Password";
      });
    } else {
      setState(() {
        _errorMessage = "";
      });
    }
  }
}
