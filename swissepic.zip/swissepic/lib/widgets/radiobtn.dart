// ignore_for_file: camel_case_types, prefer_const_constructors

import 'package:flutter/material.dart';

class radiobtn extends StatefulWidget {
  const radiobtn({super.key});

  @override
  State<radiobtn> createState() => _radiobtnState();
}

class _radiobtnState extends State<radiobtn> {
  String selectedValue = '';
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Radio(
          value: 'YES',
          groupValue: selectedValue,
          onChanged: (value) {
            setState(() {
              selectedValue = value as String;
            });
          },
        ),
        Text('Yes'),
        SizedBox(width: 20), // Add some space between the radio buttons
        Radio(
          value: 'NO',
          groupValue: selectedValue,
          onChanged: (value) {
            setState(() {
              selectedValue = value as String;
            });
          },
        ),
        Text('No'),
      ],
    );
  }
}
