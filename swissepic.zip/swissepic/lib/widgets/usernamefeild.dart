// ignore_for_file: camel_case_types, prefer_const_constructors

import 'package:flutter/material.dart';

class username extends StatefulWidget {
  const username({super.key});

  @override
  State<username> createState() => _usernameState();
}

class _usernameState extends State<username> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextFormField(
          style: TextStyle(color: Colors.grey),
          cursorHeight: 18,
          keyboardType: TextInputType.emailAddress,
          // controller: _usernameController,
          decoration: const InputDecoration(
              contentPadding: EdgeInsets.all(20.0),
              fillColor: Color(0xff303236),
              // errorText: "Email ",
              // fillColor: Color(0xff21242D),
              alignLabelWithHint: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(10),
                ),
                borderSide: BorderSide(color: Colors.grey),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(14)),
                borderSide: BorderSide(
                  color: Color(0xff7B7B7B),
                ),
              ),
              prefixIcon: Icon(
                Icons.person_2_outlined,
                color: Colors.grey,
              ),
              hintText: "Username",
              hintStyle: TextStyle(
                color: Colors.grey,
                fontSize: 14,
              ),
              isCollapsed: true),
        ),
        SizedBox(
          height: 20,
        ),
      ],
    );
  }
}
