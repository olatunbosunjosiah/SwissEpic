// ignore_for_file: camel_case_types, prefer_const_constructors, prefer_const_literals_to_create_immutables
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:swissepic/add%20expenses.dart';
import 'package:swissepic/fillup.dart';
import 'package:swissepic/models/car.dart';
import 'package:swissepic/models/readcar.dart';
import 'package:swissepic/notification.dart';

import 'driverchecklist.dart';
import 'markdamage2.dart';
import 'vehicle details.dart';

class CheckInPage extends StatelessWidget {
  final String carId;
  final String plateNo;
  final String imagePath; // Add the imagePath variable

  const CheckInPage(
      {super.key,
      required this.carId,
      required this.plateNo,
      required this.imagePath});

  @override
  Widget build(BuildContext context) {
    // Your CheckInPage content
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff8FD1FF),
        centerTitle: true,
        leading: Builder(
          builder: (BuildContext context) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap: () {
                  Scaffold.of(context).openDrawer();
                },
                child: Image(
                  image: AssetImage("assets/swisslogo.png"),
                  width: MediaQuery.of(context).size.width / 2,
                ),
              ),
            );
          },
        ),
        title: Image(
          image: AssetImage("assets/homemain.png"),
          width: MediaQuery.of(context).size.width / 3,
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image(
              image: AssetImage("assets/search.png"),
              width: MediaQuery.of(context).size.width / 16,
            ),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF162033), Color(0xFF2C85BC)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                children: [
                  Icon(
                    Icons.menu,
                    color: Colors.white,
                  ),
                ],
              ),
            ),
            Center(
              child: Column(
                children: [
                  Text(carId,
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: MediaQuery.of(context).size.width / 20)),
                  Text(" $plateNo",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                          fontSize: MediaQuery.of(context).size.width / 20)),
                  //space
                  SizedBox(
                    height: MediaQuery.of(context).size.height / 80,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      //row1
                      Padding(
                        padding: EdgeInsets.only(
                          left: MediaQuery.of(context).size.width / 80,
                          right: MediaQuery.of(context).size.width / 80,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: InkWell(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => fillup()));
                                },
                                child: Column(
                                  children: [
                                    Image(
                                      image: AssetImage("assets/car.png"),
                                      width: MediaQuery.of(context).size.width /
                                          15,
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Add Refill",
                                      style: TextStyle(
                                          fontSize: MediaQuery.of(context)
                                                  .size
                                                  .width /
                                              30,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: InkWell(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              vehicledetails()));
                                },
                                child: Column(
                                  children: [
                                    Image(
                                      image: AssetImage("assets/service.png"),
                                      width: MediaQuery.of(context).size.width /
                                          15,
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Add Service",
                                      style: TextStyle(
                                          fontSize: MediaQuery.of(context)
                                                  .size
                                                  .width /
                                              30,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: InkWell(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              driverchecklist()));
                                },
                                child: Column(
                                  children: [
                                    Image(
                                      image: AssetImage("assets/remarks.png"),
                                      width: MediaQuery.of(context).size.width /
                                          15,
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Add Remarks",
                                      style: TextStyle(
                                          fontSize: MediaQuery.of(context)
                                                  .size
                                                  .width /
                                              30,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      //space
                      SizedBox(
                        height: MediaQuery.of(context).size.height / 40,
                      ),
                      //row2
                      Padding(
                        padding: EdgeInsets.only(
                          right: MediaQuery.of(context).size.width / 40,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Column(
                                children: [
                                  Image(
                                    image: AssetImage("assets/startingkm.png"),
                                    width:
                                        MediaQuery.of(context).size.width / 20,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    "Starting km",
                                    style: TextStyle(
                                        fontSize:
                                            MediaQuery.of(context).size.width /
                                                30,
                                        color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Column(
                                children: [
                                  Image(
                                    image: AssetImage("assets/endingkm.png"),
                                    width:
                                        MediaQuery.of(context).size.width / 20,
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    "Ending km",
                                    style: TextStyle(
                                        fontSize:
                                            MediaQuery.of(context).size.width /
                                                30,
                                        color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: InkWell(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => markdamage2()));
                                },
                                child: Column(
                                  children: [
                                    Image(
                                      image: AssetImage("assets/carclean.png"),
                                      width: MediaQuery.of(context).size.width /
                                          15,
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      "Car Clean",
                                      style: TextStyle(
                                          fontSize: MediaQuery.of(context)
                                                  .size
                                                  .width /
                                              30,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height / 40,
                      ),
                      Center(
                        child: Padding(
                          padding: EdgeInsets.all(10.0),
                          child: InkWell(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => addexpenses()));
                            },
                            child: Column(
                              children: [
                                Image(
                                  image: AssetImage("assets/parkingcost.png"),
                                  width: MediaQuery.of(context).size.width / 20,
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  "Parking Cost",
                                  style: TextStyle(
                                      fontSize:
                                          MediaQuery.of(context).size.width /
                                              30,
                                      color: Colors.white),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      Container(
                        padding: EdgeInsets.all(10.0), // Add padding here
                        width: MediaQuery.of(context).size.width,
                        child: Image.network(
                          imagePath,
                          width: 200, // Set the desired width
                          height: 200, // Set the desired height
                          fit: BoxFit
                              .contain, // Adjust the BoxFit to control how the image scales
                        ), // Display the image using the provided path
                      ),
                      Center(
                        child: ElevatedButton(
                          onPressed: () {
                            purchaseCar();
updateField();                            
                            // Prepare notifications data
                            final notifications = [
                              {
                                'carId': carId,
                                'plateNo': plateNo,
                                'imageUrl': imagePath,
                              },
                              // Add more notifications as needed
                            ];
                            
                            // Navigate to the NotificationPage
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => NotificationPage(
                                    notifications: notifications),
                              ),
                            );
                          },
                          child: Text('done'),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
Future<void> purchaseCar () async {
  try {
    User? user = FirebaseAuth.instance.currentUser;
     String userId = user!.uid;
    // Create a reference to the user's document
    DocumentReference userRef = FirebaseFirestore.instance.collection("users").doc(userId);

    // Reference to the subcollection "checkedInCars" under the user's document
    CollectionReference checkedInCarsRef = userRef.collection("checkedInCars");

    // Add a new document to the subcollection
    await checkedInCarsRef.add({
      'carId': userId,
      'status':true,
      // Other car-related data
    });

    print('Subcollection added successfully');
  } catch (e) {
    print('Error adding subcollection: $e');
  }
}

Future<void> updateStatusToFalse() async {
  try {
    final CollectionReference collectionReference = FirebaseFirestore.instance.collection('cars');
    
    // Update the status field to false for the document with the given documentId
    String? documentId;
    await collectionReference.doc(documentId).update({
      'status': false,
    });

    print('Status updated to false for document $documentId');
  } catch (e) {
    print('Error updating status: $e');
  }
}
Future<void> updateField(String documentID) async {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final CollectionReference _collection = FirebaseFirestore.instance.collection('cars');

  try {
    // Check if the document exists before attempting to update
    DocumentSnapshot documentSnapshot = await _collection.doc(documentID).get();
    
    if (documentSnapshot.exists) {
      // Document exists, proceed with the update
      await _collection.doc(documentID).update({
        'status': false,
      });
      print('Document successfully updated');
    } else {
      // Document does not exist
      print('Document with ID $documentID does not exist.');
    }
  } catch (e) {
    print('Error updating document: $e');
  }
}

// Future<void> addSubcollectionToUser(String carID, String userID) async {
//   try {
//     User? user = FirebaseAuth.instance.currentUser;
//      String userId = user!.uid;
//     // Create an instance of FirebaseFirestore
//     FirebaseFirestore firestore = FirebaseFirestore.instance;

//     // Reference to the car document in the "cars" collection
//     CollectionReference carsCollection = firestore.collection("users").doc(userID).collection("checkedInCars");
    
//     // Now, you can work with the collection reference as needed
//     // For example, you can add a new document to the collection
//     await carsCollection.add({
//       'carID': userID,
//       'status': true,
//       // Other car-related data
//     });

//   } catch (e) {
//     print('Error updating car document: $e');
//   }
// }




// class homescreen extends StatefulWidget {
//    final String carId; // Replace with the actual data type of your ID
//   final String plateNo; // Replace with the actual data type of your plate number

//   homescreen({required this.carId, required this.plateNo});

//   @override
//   State<homescreen> createState() => _homescreenState();
// }

// class _homescreenState extends State<homescreen> {
//   @override
//   Widget build(BuildContext context) {
  
//   }
// }
