// ignore_for_file: file_names
// // ignore_for_file: prefer_const_constructors, file_names, prefer_const_literals_to_create_immutables, non_constant_identifier_names


// import 'package:flutter/material.dart';
// import 'package:hidden_drawer_menu/hidden_drawer_menu.dart';



// class DrawerPkg extends StatefulWidget {
//   const DrawerPkg({super.key});

//   @override
//   State<DrawerPkg> createState() => _DrawerPkgState();
// }

// class _DrawerPkgState extends State<DrawerPkg> {
//   late List<ScreenHiddenDrawer> _Pages = [];

//   final mytextstyle = TextStyle(fontSize: 16, color: Colors.white54);
//   final selectedTextstyle =
//       TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white);

//   @override
//   void initState() {
//     super.initState();
//     _Pages = [
//       ScreenHiddenDrawer(
//         ItemHiddenMenu(
//           name: "HomePage",

//           baseStyle: mytextstyle,
//           selectedStyle: selectedTextstyle,
//           // colorLineSelected: Colors.green,
//         ),
//         drawerHome(),
//       ),
//       ScreenHiddenDrawer(
//         ItemHiddenMenu(
//           name: "Peoples",
//           baseStyle: mytextstyle,
//           selectedStyle: selectedTextstyle,
//           // colorLineSelected: Colors.green,
//         ),
//         People(),
//       ),
//       ScreenHiddenDrawer(
//           ItemHiddenMenu(
//               name: "Favourites",
//               baseStyle: mytextstyle,
//               selectedStyle: selectedTextstyle),
//           Fav()),
//       ScreenHiddenDrawer(
//           ItemHiddenMenu(
//               name: "Setting",
//               baseStyle: mytextstyle,
//               selectedStyle: selectedTextstyle),
//           Settings()),
//       ScreenHiddenDrawer(
//           ItemHiddenMenu(
//               name: "Logout",
//               baseStyle: mytextstyle,
//               selectedStyle: selectedTextstyle),
//           drawerHome()),
//     ];
//   }

//   @override
//   Widget build(BuildContext context) {
//     return HiddenDrawerMenu(
//       backgroundColorMenu: Color(0xff2C85BC),
//       screens: _Pages,
//       initPositionSelected: 0,
//       slidePercent: 60,
//       enableScaleAnimation: true,
//       enableCornerAnimation: true,
//       // enableShadowItensMenu: true,
//     );
//   }
// }
