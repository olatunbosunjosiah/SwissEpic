// ignore_for_file: camel_case_types, prefer_const_constructors

import 'package:flutter/material.dart';

class markdamage3 extends StatefulWidget {
  const markdamage3({super.key});

  @override
  State<markdamage3> createState() => _markdamage3State();
}

class _markdamage3State extends State<markdamage3> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff8FD1FF),
        centerTitle: true,
        leading: Builder(
          builder: (BuildContext context) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap: () {
                  Scaffold.of(context).openDrawer();
                },
                child: Image(
                  image: AssetImage("assets/swisslogo.png"),
                  width: MediaQuery.of(context).size.width / 2,
                ),
              ),
            );
          },
        ),
        title: Image(
          image: AssetImage("assets/report.png"),
          width: MediaQuery.of(context).size.width / 3,
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image(
              image: AssetImage("assets/search.png"),
              width: MediaQuery.of(context).size.width / 16,
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 20, top: 20),
                child: Text(
                  "MARK THE DAMAGE\nSPOT",
                  style: TextStyle(
                    fontSize: MediaQuery.of(context).size.width / 18,
                    fontFamily: "Poppins",
                    color: Color(0xff2C85BC),
                    overflow: TextOverflow.ellipsis,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.start,
                ),
              ),
              IconButton(
                onPressed: () {},
                icon: Icon(Icons.menu),
                iconSize: 35,
                color: Color(0xff2C85BC),
              )
            ],
          ),
          //center text
          SizedBox(
            height: 20,
          ),
          Text(
            "Mercedes-SPRINTER 519 ",
            style: TextStyle(
              fontSize: MediaQuery.of(context).size.width / 20,
              fontFamily: "Poppins",
              color: Colors.black,
              overflow: TextOverflow.ellipsis,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.start,
          ),
          SizedBox(
            height: 20,
          ),
          Image.asset("assets/benz3.png"),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: EdgeInsets.only(
                left: MediaQuery.of(context).size.width / 6,
                right: MediaQuery.of(context).size.width / 6),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(60),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10), // <-- Radius
                ),
                backgroundColor: Color(0xff2C85BC), // NEW
                elevation: 10,
              ),
              onPressed: () {
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (context) => homescreen()),
                // );
              },
              child: Text(
                "Submit",
                softWrap: true,
                textAlign: TextAlign.center,
                style: TextStyle(
                  decoration: TextDecoration.none,
                  color: Colors.white,
                  fontWeight: FontWeight.w400,
                  fontSize: MediaQuery.of(context).size.width / 18,
                  fontFamily: 'SF Pro Display',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
