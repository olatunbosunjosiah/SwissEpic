// ignore_for_file: unused_import, prefer_const_constructors

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:swissepic/add%20expenses.dart';
import 'package:swissepic/driverchecklist.dart';
import 'package:swissepic/fillup.dart';
import 'package:swissepic/firebase_options.dart';
import 'package:swissepic/home.dart';
import 'package:swissepic/map.dart';
import 'package:swissepic/markdamage.dart';
import 'package:swissepic/register.dart';
import 'package:swissepic/report.dart';
import 'package:swissepic/services/firebase_auth_methods.dart';
import 'package:swissepic/vehicle%20details.dart';

import 'bottomnav.dart';
import 'login.dart';
import 'markdamage2.dart';
import 'markdamage3.dart';
import 'markdamage4.dart';
import 'markdamage5.dart';
import 'splash.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(
    ChangeNotifierProvider(
      create: (context) => FormCompletionProvider(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Swiss Epic Tour',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // TRY THIS: Try running your application with "flutter run". You'll see
        // the application has a blue toolbar. Then, without quitting the app,
        // try changing the seedColor in the colorScheme below to Colors.green2
        // and then invoke "hot reload" (save your changes or press the "hot
        // reload" button in a Flutter-supported IDE, or press "r" if you used
        // the command line to start the app).
        //
        // Notice that the counter didn't reset back to zero; the application
        // state is not lost during the reload. To reset the state, use hot
        // restart instead.
        //
        // This works for code too, not just values: Most code changes can be
        // tested with just a hot reload.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: splash(),
    );
  }
}
