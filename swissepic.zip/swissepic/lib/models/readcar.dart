import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:swissepic/models/car.dart';

Stream<List<Car>> readCar()=>FirebaseFirestore.instance
    .collection('cars')
    .orderBy('id', descending: false)
    .snapshots()
    .map((snapshot) =>
        snapshot.docs.map((doc) => Car.fromJson(doc.data())).toList());

        updatingField(String carId) async {
   await FirebaseFirestore.instance
      .collection('cars')
      .doc(carId)
      .update({'status': false});
}