class Car {
  String? id;
  String? name;
  String? imageUrl;
  String? plateNo;
  bool? status;
  String? currentPickedUserId;

  Car({
    this.id,
    this.name,
    this.imageUrl,
    this.plateNo,
    this.status,
    this.currentPickedUserId,
  });

  Car.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    imageUrl = json['imageUrl'];
    plateNo = json['plateNo'];
    status = json['status'];
    currentPickedUserId = json['currentPickedUserId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['imageUrl'] = imageUrl;
    data['plateNo'] = plateNo;
    data['status'] = status;
    data['currentPickedUserId'] = currentPickedUserId;
    return data;
  }
}
