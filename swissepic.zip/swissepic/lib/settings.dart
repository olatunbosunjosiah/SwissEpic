// ignore_for_file: camel_case_types, prefer_const_constructors, prefer_const_literals_to_create_immutables
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:swissepic/login.dart';
import 'package:swissepic/widgets/showSnackbar.dart';

import 'widgets/app_text.dart';

class settingsscreen extends StatefulWidget {
  const settingsscreen({super.key});

  @override
  State<settingsscreen> createState() => _settingsscreenState();
}

class _settingsscreenState extends State<settingsscreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff8FD1FF),
        centerTitle: true,
        leading: Builder(
          builder: (BuildContext context) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap: () {
                  Scaffold.of(context).openDrawer();
                },
                child: Image(
                  image: AssetImage("assets/swisslogo.png"),
                  width: MediaQuery.of(context).size.width / 2,
                ),
              ),
            );
          },
        ),
        title: Image(
          image: AssetImage("assets/settingsmain.png"),
          width: MediaQuery.of(context).size.width / 3,
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image(
              image: AssetImage("assets/search.png"),
              width: MediaQuery.of(context).size.width / 16,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF2C85BC), Color(0xFF2C85BC)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.only(
                  top: MediaQuery.of(context).size.height / 30,
                  left: MediaQuery.of(context).size.width / 30,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Image(
                          image: AssetImage("assets/profileimg.png"),
                          width: MediaQuery.of(context).size.width / 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Column(
                            children: [
                              AppText(text: "Hey", color: Colors.white),
                              AppText(
                                  text: "M3",
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height / 10,
                    ),
                    InkWell(
                      onTap: () {},
                      child: Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).size.height / 20),
                        child: Row(
                          children: [
                            Image(
                              image: AssetImage("assets/recentactivity.png"),
                              width: MediaQuery.of(context).size.width / 20,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            AppText(
                              text: "Recent Activity",
                              color: Colors.white,
                              fontSize: MediaQuery.of(context).size.width / 30,
                            ),
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {},
                      child: Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).size.height / 20),
                        child: Row(
                          children: [
                            Image(
                              image: AssetImage("assets/profileicon.png"),
                              width: MediaQuery.of(context).size.width / 20,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            AppText(
                              text: "Company Profile",
                              color: Colors.white,
                              fontSize: MediaQuery.of(context).size.width / 30,
                            ),
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {},
                      child: Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).size.height / 20),
                        child: Row(
                          children: [
                            Image(
                              image: AssetImage("assets/notificationicon.png"),
                              width: MediaQuery.of(context).size.width / 20,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            AppText(
                              text: "Notifications",
                              color: Colors.white,
                              fontSize: MediaQuery.of(context).size.width / 30,
                            ),
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {},
                      child: Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).size.height / 20),
                        child: Row(
                          children: [
                            Image(
                              image: AssetImage("assets/privacyicon.png"),
                              width: MediaQuery.of(context).size.width / 20,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            AppText(
                              text: "Privacy Policy",
                              color: Colors.white,
                              fontSize: MediaQuery.of(context).size.width / 30,
                            ),
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {},
                      child: Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).size.height / 20),
                        child: Row(
                          children: [
                            Image(
                              image: AssetImage("assets/settingsicon.png"),
                              width: MediaQuery.of(context).size.width / 20,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            AppText(
                              text: "Account Settings",
                              color: Colors.white,
                              fontSize: MediaQuery.of(context).size.width / 30,
                            ),
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {},
                      child: Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).size.height / 20),
                        child: Row(
                          children: [
                            Image(
                              image: AssetImage("assets/helpicon.png"),
                              width: MediaQuery.of(context).size.width / 20,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            AppText(
                              text: "Help & feedback",
                              color: Colors.white,
                              fontSize: MediaQuery.of(context).size.width / 30,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height / 15,
                    ),
                    Image(
                      image: AssetImage("assets/swisslogo.png"),
                      width: MediaQuery.of(context).size.width / 7,
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height / 60,
                    ),
                    InkWell(
                      onTap: () async {
                        try {
                          final naviagtor = Navigator.of(context);
                          final auth = FirebaseAuth.instance;
                          await auth.signOut();
                          naviagtor.push(
                            MaterialPageRoute(builder: (context) => login()),
                          );
                        } catch (e) {
                          showSnackBar(context, "Logout failed");
                        }
                      },
                      child: Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).size.height / 20),
                        child: Row(
                          children: [
                            Image(
                              image: AssetImage("assets/logouticon.png"),
                              width: MediaQuery.of(context).size.width / 20,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            AppText(
                              text: "Log out",
                              color: Colors.white,
                              fontSize: MediaQuery.of(context).size.width / 30,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
