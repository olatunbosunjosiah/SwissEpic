import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:swissepic/services/firebase_auth_methods.dart';

class vehicledetails extends StatefulWidget {
  const vehicledetails({Key? key}) : super(key: key);

  @override
  State<vehicledetails> createState() => _vehicledetailsState();
}

class _vehicledetailsState extends State<vehicledetails> {
  String selectedValue = '';
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  TextEditingController makeController = TextEditingController();
  TextEditingController modelController = TextEditingController();
  TextEditingController licenceNoController = TextEditingController();
  TextEditingController vinController = TextEditingController();
  TextEditingController insuranceController = TextEditingController();
  TextEditingController remarksController = TextEditingController();

  void storeVehicleDetails() {
    // You should create an instance of FirebaseAuthMethods
    FirebaseAuthMethods(FirebaseAuth.instance).storeVehicleDetails(
      makeController: makeController.text,
      modelController: modelController.text,
      licenceNoController: licenceNoController.text,
      vinController: vinController.text,
      insuranceController: insuranceController.text,
      remarksController: remarksController.text,
      context: context,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: const Color(0xff2C85BC),
        leading: IconButton(
          onPressed: () {},
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        title: Text(
          "Enter Vehicle Details",
          style: TextStyle(
            fontSize: MediaQuery.of(context).size.width / 24,
            fontFamily: "Poppins",
            color: Colors.white,
            overflow: TextOverflow.ellipsis,
            fontWeight: FontWeight.normal,
          ),
          textAlign: TextAlign.center,
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(
              Icons.save,
              color: Colors.white,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          SizedBox(
            height: MediaQuery.of(context).size.height / 10,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: TextFormField(
              controller: makeController,
              cursorHeight: 18,
              style: GoogleFonts.poppins(
                color: Colors.black,
                fontSize: 17,
              ),
              decoration: const InputDecoration(
                fillColor: Colors.white,
                contentPadding: EdgeInsets.all(10),
                alignLabelWithHint: true,
                border: UnderlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(14)),
                  borderSide: BorderSide(color: Colors.black),
                ),
                enabledBorder: UnderlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(14)),
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                labelText: "Make",
                hintText: "Mercedes",
                labelStyle: TextStyle(
                  color: Colors.black,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: TextFormField(
              controller: modelController,
              cursorHeight: 18,
              style: GoogleFonts.poppins(
                color: Colors.black,
                fontSize: 17,
              ),
              decoration: const InputDecoration(
                fillColor: Colors.white,
                contentPadding: EdgeInsets.all(10),
                alignLabelWithHint: true,
                border: UnderlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(14)),
                  borderSide: BorderSide(color: Colors.black),
                ),
                enabledBorder: UnderlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(14)),
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                labelText: "Model",
                hintText: "V-class",
                labelStyle: TextStyle(
                  color: Colors.black,
                  fontSize: 14,
                ),
              ),
            ),
          ),

          // Other input fields ...
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: TextFormField(
              controller: vinController,
              cursorHeight: 18,
              style: GoogleFonts.poppins(
                color: Colors.black,
                fontSize: 17,
              ),
              decoration: const InputDecoration(
                fillColor: Colors.white,
                contentPadding: EdgeInsets.all(10),
                alignLabelWithHint: true,
                border: UnderlineInputBorder(
                  // Remove 'borderRadius' here
                  borderSide: BorderSide(color: Colors.black),
                ),
                enabledBorder: UnderlineInputBorder(
                  // Remove 'borderRadius' here
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                hintText: "VIN",
                labelStyle: TextStyle(
                  color: Colors.black,
                  fontSize: 14,
                ),
              ),
            ),
          ),

          ElevatedButton(
            onPressed: () {
              storeVehicleDetails();
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),

          SizedBox(
            height: MediaQuery.of(context).size.height / 10,
          ),
        ]),
      ),
    );
  }
}
