// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors, camel_case_types

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:swissepic/services/firebase_auth_methods.dart';


class driverchecklist extends StatefulWidget {
  const driverchecklist({super.key});

  @override
  State<driverchecklist> createState() => _driverchecklistState();
}

class _driverchecklistState extends State<driverchecklist> {
    TextEditingController drivernameController = TextEditingController();

  String selectedValue = '';
  String selectedValue2 = '';
  String selectedValue3 = '';
  String selectedValue4 = '';
  String selectedValue5 = '';
  String selectedValue6 = '';
  String selectedValue7 = '';
  String selectedPlateNo = 'Vehicle FSprinter ZH 311504'; // Default selected value selectedValue;
  
  void storeInfo() async{
     FirebaseAuthMethods(FirebaseAuth.instance).storeInfo(
      selectedValue:selectedValue,
      selectedPlateNo: selectedPlateNo,
      selectedValue2:selectedValue2,
      selectedValue3:selectedValue3,
      selectedValue4:selectedValue4,
      selectedValue5: selectedValue5,
      selectedValue6: selectedValue6,
      selectedValue7: selectedValue7,
      drivernameController: drivernameController.text,
      context: context);

       // Notify the provider that the driver checklist form is completed
    Provider.of<FormCompletionProvider>(context, listen: false)
        .updateDriverChecklistFormStatus(true);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          children: [
            SizedBox(
              height: 100,
            ),
            Center(
              child: Image(image: AssetImage("assets/driver.png")),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height / 30,
            ),
            Padding(
              
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Flexible(
                child: TextFormField(
                  cursorHeight: 18,
                  style: GoogleFonts.poppins(
                    // backgroundColor: Color(0xff21242D),
                    color: Colors.black,
                    fontSize: 17,
                  ),
                  controller: drivernameController,
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    contentPadding: EdgeInsets.all(10),

                    // errorText: "Email ",
                    // fillColor: Color(0xff21242D),
                    alignLabelWithHint: true,
                    border: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    // labelText: "Model",
                    hintText: "Driver Name*",
                    prefixIcon: Icon(Icons.person_2_outlined),
                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ),
            //radio  btn
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Radio(
                  value: 'checkin',
                  groupValue: selectedValue,
                  onChanged: (value) {
                    setState(() {
                      selectedValue = value as String;
                    });
                  },
                ),
                Text('Check in'),
                SizedBox(width: 20), // Add some space between the radio buttons
                Radio(
                  value: 'Checkout',
                  groupValue: selectedValue,
                  onChanged: (value) {
                    setState(() {
                      selectedValue = value as String;
                    });
                  },
                ),
                Text('Check out'),
              ],
            ),

            //new feild

            Container(
              alignment: Alignment.centerLeft, // Align the container to the left
      // padding: EdgeInsets.all(16.0), // Add padding for spacing
              padding:EdgeInsets.fromLTRB(10, 0, 10, 0),
              margin: EdgeInsets.all(4.0),
              decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0), // Adjust the border radius as needed
            border: Border.all(
              color: Colors.grey, // Border color
              width: 1.0, // Border width
            ),
          ),
              child: Column(
      children: [
        DropdownButton<String>(
          value: selectedPlateNo,
          onChanged: (String? newValue) {
            setState(() {
              selectedPlateNo = newValue!;
             
            });
          },
          items: <String>['Vehicle FSprinter ZH 311504', 'Vehicle Sprinter ZH 11504', 'Vehicle Sprinter ZH 31504', 'Vehicle Sprinter ZH 3104']
              .map<DropdownMenuItem<String>>(
                (String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Row(
                      children: [
                        Icon(Icons.car_rental_outlined), // Add your desired icon here
                        SizedBox(width: 8.0), // Add spacing between icon and text
                        Text(value),
                      ],
                    ),
                  );
                },
              )
              .toList(),
        ),
      ],
    ),
            ),
            //row
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 20, top: 0),
                  child: Text(
                    "Is there any damage to the vehicle?",
                    style: TextStyle(
                      fontSize: MediaQuery.of(context).size.width / 24,
                      fontFamily: "Poppins",
                      color: Colors.black,
                      overflow: TextOverflow.ellipsis,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.start,
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Radio(
                  value: 'YES',
                  groupValue: selectedValue2,
                  onChanged: (value) {
                    setState(() {
                      selectedValue2 = value as String;
                    });
                  },
                ),
                Text('Yes'),
                SizedBox(width: 20), // Add some space between the radio buttons
                Radio(
                  value: 'NO',
                  groupValue: selectedValue2,
                  onChanged: (value) {
                    setState(() {
                      selectedValue2 = value as String;
                    });
                  },
                ),
                Text('No'),
              ],
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height / 100,
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Flexible(
                child: TextFormField(
                  cursorHeight: 18,
                  style: GoogleFonts.poppins(
                    // backgroundColor: Color(0xff21242D),
                    color: Colors.black,
                    fontSize: 17,
                  ),
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    contentPadding: EdgeInsets.all(10),

                    // errorText: "Email ",
                    // fillColor: Color(0xff21242D),
                    alignLabelWithHint: true,
                    border: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    // labelText: "Model",
                    hintText: "Others",

                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            //new
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 20, top: 0),
                  child: Text(
                    "The tire profile meets the requirements?",
                    style: TextStyle(
                      fontSize: MediaQuery.of(context).size.width / 26,
                      fontFamily: "Poppins",
                      color: Colors.black,
                      overflow: TextOverflow.ellipsis,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.start,
                  ),
                ),
              ],
            ),
            Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Radio(
          value: 'YES',
          groupValue: selectedValue3,
          onChanged: (value) {
            setState(() {
              selectedValue3 = value as String;
            });
          },
        ),
        Text('Yes'),
        SizedBox(width: 20), // Add some space between the radio buttons
        Radio(
          value: 'No',
          groupValue: selectedValue3,
          onChanged: (value) {
            setState(() {
              selectedValue3 = value as String;
            });
          },
        ),
        Text('NO'),
      ],
    ),
  
            SizedBox(
              height: MediaQuery.of(context).size.height / 100,
            ),
            //new
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 20, top: 0),
                  child: Text(
                    "Is the vehicle clean inside?",
                    style: TextStyle(
                      fontSize: MediaQuery.of(context).size.width / 26,
                      fontFamily: "Poppins",
                      color: Colors.black,
                      overflow: TextOverflow.ellipsis,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.start,
                  ),
                ),
              ],
            ),
            Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Radio(
          value: 'YES',
          groupValue: selectedValue4,
          onChanged: (value) {
            setState(() {
              selectedValue4 = value as String;
            });
          },
        ),
        Text('Yes'),
        SizedBox(width: 20), // Add some space between the radio buttons
        Radio(
          value: 'NO',
          groupValue: selectedValue4,
          onChanged: (value) {
            setState(() {
              selectedValue4 = value as String;
            });
          },
        ),
        Text('No'),
      ],
    ),
            SizedBox(
              height: MediaQuery.of(context).size.height / 100,
            ),
            //new

            SizedBox(
              height: MediaQuery.of(context).size.height / 100,
            ),
            //new
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 20, top: 0),
                  child: Text(
                    "Is the vehicle clean on the outside?",
                    style: TextStyle(
                      fontSize: MediaQuery.of(context).size.width / 26,
                      fontFamily: "Poppins",
                      color: Colors.black,
                      overflow: TextOverflow.ellipsis,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.start,
                  ),
                ),
              ],
            ),
            Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Radio(
          value: 'YES',
          groupValue: selectedValue5,
          onChanged: (value) {
            setState(() {
              selectedValue5 = value as String;
            });
          },
        ),
        Text('Yes'),
        SizedBox(width: 20), // Add some space between the radio buttons
        Radio(
          value: 'NO',
          groupValue: selectedValue5,
          onChanged: (value) {
            setState(() {
              selectedValue5 = value as String;
            });
          },
        ),
        Text('No'),
      ],
    ),
            SizedBox(
              height: MediaQuery.of(context).size.height / 100,
            ),
            //new
            SizedBox(
              height: MediaQuery.of(context).size.height / 100,
            ),
            //new
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 20, top: 0),
                  child: Text(
                    "Is there any damage to the vehicle?",
                    style: TextStyle(
                      fontSize: MediaQuery.of(context).size.width / 26,
                      fontFamily: "Poppins",
                      color: Colors.black,
                      overflow: TextOverflow.ellipsis,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.start,
                  ),
                ),
              ],
            ),
            Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Radio(
          value: 'YES',
          groupValue: selectedValue6,
          onChanged: (value) {
            setState(() {
              selectedValue6 = value as String;
            });
          },
        ),
        Text('Yes'),
        SizedBox(width: 20), // Add some space between the radio buttons
        Radio(
          value: 'NO',
          groupValue: selectedValue6,
          onChanged: (value) {
            setState(() {
              selectedValue6 = value as String;
            });
          },
        ),
        Text('No'),
      ],
    ),
            SizedBox(
              height: MediaQuery.of(context).size.height / 100,
            ),

            //new
            Padding(
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: Flexible(
                child: TextFormField(
                  cursorHeight: 18,
                  style: GoogleFonts.poppins(
                    // backgroundColor: Color(0xff21242D),
                    color: Colors.black,
                    fontSize: 17,
                  ),
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    contentPadding: EdgeInsets.all(10),

                    // errorText: "Email ",
                    // fillColor: Color(0xff21242D),
                    alignLabelWithHint: true,
                    border: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(14)),
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    // labelText: "Model",
                    hintText: "Others",

                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),

            //new
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 20, top: 0),
                  child: Text(
                    "Is The vehicle fuel tank full?",
                    style: TextStyle(
                      fontSize: MediaQuery.of(context).size.width / 26,
                      fontFamily: "Poppins",
                      color: Colors.black,
                      overflow: TextOverflow.ellipsis,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.start,
                  ),
                ),
              ],
            ),
            Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Radio(
          value: 'YES',
          groupValue: selectedValue7,
          onChanged: (value) {
            setState(() {
              selectedValue7 = value as String;
            });
          },
        ),
        Text('Yes'),
        SizedBox(width: 20), // Add some space between the radio buttons
        Radio(
          value: 'NO',
          groupValue: selectedValue7,
          onChanged: (value) {
            setState(() {
              selectedValue7 = value as String;
            });
          },
        ),
        Text('No'),
      ],
    ),
            ElevatedButton(
  onPressed: (){
    storeInfo();
    Navigator.pop(context); },
  child: Text('Save'),
),
            SizedBox(
              height: MediaQuery.of(context).size.height / 10,
            ),
            
          ],
        ),
      ),
    );
  }
}
